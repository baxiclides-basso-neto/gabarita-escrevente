import { useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  BookOpen, 
  CheckCircle, 
  Target, 
  TrendingUp, 
  Award,
  ArrowRight,
  BarChart3,
  Flame,
  Home
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useAuth } from '@/hooks/useAuth';
import { topicos } from '@/data/questoes';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';

export function DashboardPage() {
  const navigate = useNavigate();
  const { isAuthenticated, user, progress } = useAuth();

  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/login');
    }
  }, [isAuthenticated, navigate]);

  if (!isAuthenticated || !user) {
    return null;
  }

  const accuracyRate = progress.questionsAnswered > 0 
    ? Math.round((progress.correctAnswers / progress.questionsAnswered) * 100) 
    : 0;

  const chartData = topicos.map(topico => {
    const topicProg = progress.topicProgress[topico.nome];
    return {
      name: topico.nome.split(' ')[0],
      answered: topicProg?.answered || 0,
      correct: topicProg?.correct || 0
    };
  });

  const pieData = [
    { name: 'Acertos', value: progress.correctAnswers, color: '#22c55e' },
    { name: 'Erros', value: progress.questionsAnswered - progress.correctAnswers, color: '#ef4444' }
  ];

  return (
    <div className="min-h-screen bg-[#0f172a] pt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Back Button */}
        <div className="mb-4">
          <Link
            to="/"
            className="inline-flex items-center space-x-2 text-gray-400 hover:text-white transition-colors"
          >
            <Home className="w-5 h-5" />
            <span>Voltar à página inicial</span>
          </Link>
        </div>
        
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <div>
              <h1 className="text-3xl font-bold text-white">
                Olá, <span className="text-[#c9a227]">{user.name.split(' ')[0]}</span>!
              </h1>
              <p className="text-gray-400 mt-1">
                Continue sua preparação para o TJSP
              </p>
            </div>
            <div className="mt-4 md:mt-0 flex items-center space-x-4">
              {progress.streakDays > 0 && (
                <div className="flex items-center space-x-2 px-4 py-2 rounded-lg bg-orange-500/10 border border-orange-500/30">
                  <Flame className="w-5 h-5 text-orange-500" />
                  <span className="text-orange-400 font-medium">{progress.streakDays} dias seguidos</span>
                </div>
              )}
              <Link to="/questoes">
                <Button className="bg-gradient-to-r from-[#c9a227] to-[#a88a1f] text-[#0f172a] font-semibold">
                  <BookOpen className="w-4 h-4 mr-2" />
                  Resolver Questões
                </Button>
              </Link>
            </div>
          </div>
        </motion.div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {[
            { 
              icon: BookOpen, 
              label: 'Questões Respondidas', 
              value: progress.questionsAnswered,
              color: 'from-blue-500 to-blue-600'
            },
            { 
              icon: CheckCircle, 
              label: 'Acertos', 
              value: progress.correctAnswers,
              color: 'from-green-500 to-green-600'
            },
            { 
              icon: Target, 
              label: 'Taxa de Acerto', 
              value: `${accuracyRate}%`,
              color: 'from-[#c9a227] to-[#a88a1f]'
            },
            { 
              icon: Flame, 
              label: 'Dias Seguidos', 
              value: progress.streakDays,
              color: 'from-orange-500 to-orange-600'
            },
          ].map((stat, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="bg-[#1e293b] border-white/5">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-gray-400 text-sm">{stat.label}</p>
                      <p className="text-3xl font-bold text-white mt-1">{stat.value}</p>
                    </div>
                    <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center`}>
                      <stat.icon className="w-6 h-6 text-white" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Charts Row */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Progress Chart */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
          >
            <Card className="bg-[#1e293b] border-white/5">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <BarChart3 className="w-5 h-5 mr-2 text-[#c9a227]" />
                  Progresso por Tópico
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={chartData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                      <XAxis dataKey="name" stroke="#94a3b8" fontSize={12} />
                      <YAxis stroke="#94a3b8" fontSize={12} />
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: '#1e293b', 
                          border: '1px solid rgba(255,255,255,0.1)',
                          borderRadius: '8px'
                        }}
                      />
                      <Bar dataKey="answered" fill="#3b82f6" name="Respondidas" />
                      <Bar dataKey="correct" fill="#22c55e" name="Acertos" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Accuracy Chart */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
          >
            <Card className="bg-[#1e293b] border-white/5">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <TrendingUp className="w-5 h-5 mr-2 text-[#c9a227]" />
                  Desempenho Geral
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64 flex items-center justify-center">
                  {progress.questionsAnswered > 0 ? (
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={pieData}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={80}
                          paddingAngle={5}
                          dataKey="value"
                        >
                          {pieData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip 
                          contentStyle={{ 
                            backgroundColor: '#1e293b', 
                            border: '1px solid rgba(255,255,255,0.1)',
                            borderRadius: '8px'
                          }}
                        />
                      </PieChart>
                    </ResponsiveContainer>
                  ) : (
                    <div className="text-center">
                      <p className="text-gray-400">Resolva questões para ver seu desempenho</p>
                      <Link to="/questoes">
                        <Button className="mt-4 bg-gradient-to-r from-[#c9a227] to-[#a88a1f] text-[#0f172a]">
                          Começar
                        </Button>
                      </Link>
                    </div>
                  )}
                </div>
                {progress.questionsAnswered > 0 && (
                  <div className="flex justify-center space-x-6 mt-4">
                    <div className="flex items-center">
                      <div className="w-3 h-3 rounded-full bg-green-500 mr-2" />
                      <span className="text-gray-400 text-sm">Acertos ({progress.correctAnswers})</span>
                    </div>
                    <div className="flex items-center">
                      <div className="w-3 h-3 rounded-full bg-red-500 mr-2" />
                      <span className="text-gray-400 text-sm">Erros ({progress.questionsAnswered - progress.correctAnswers})</span>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Topic Progress */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="mb-8"
        >
          <Card className="bg-[#1e293b] border-white/5">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <Award className="w-5 h-5 mr-2 text-[#c9a227]" />
                Progresso por Tópico
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {topicos.map((topico, index) => {
                  const topicProg = progress.topicProgress[topico.nome];
                  const answered = topicProg?.answered || 0;
                  const correct = topicProg?.correct || 0;
                  const percentage = answered > 0 ? Math.round((correct / answered) * 100) : 0;
                  
                  return (
                    <div key={index}>
                      <div className="flex justify-between items-center mb-2">
                        <div>
                          <span className="text-white font-medium">{topico.nome}</span>
                          <span className="text-gray-500 text-sm ml-2">({topico.artigos})</span>
                        </div>
                        <span className="text-gray-400 text-sm">
                          {correct}/{answered} ({answered > 0 ? percentage : 0}%)
                        </span>
                      </div>
                      <div className="h-2 bg-white/5 rounded-full overflow-hidden">
                        <motion.div
                          initial={{ width: 0 }}
                          animate={{ width: `${answered > 0 ? percentage : 0}%` }}
                          transition={{ duration: 0.5, delay: index * 0.1 }}
                          className={`h-full rounded-full ${
                            percentage >= 70 ? 'bg-green-500' : 
                            percentage >= 50 ? 'bg-[#c9a227]' : 'bg-blue-500'
                          }`}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Quick Actions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7 }}
        >
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="bg-gradient-to-br from-[#1e3a5f] to-[#0f172a] border-white/5">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-xl font-bold text-white mb-2">Novo Simulado</h3>
                    <p className="text-gray-400">Resolva questões aleatórias de todos os tópicos</p>
                  </div>
                  <Link to="/questoes">
                    <Button className="bg-gradient-to-r from-[#c9a227] to-[#a88a1f] text-[#0f172a] font-semibold">
                      Iniciar
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-[#1e3a5f] to-[#0f172a] border-white/5">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-xl font-bold text-white mb-2">Continuar Estudo</h3>
                    <p className="text-gray-400">Retome de onde você parou</p>
                  </div>
                  <Link to="/questoes">
                    <Button variant="outline" className="border-white/20 text-white hover:bg-white/5">
                      Continuar
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
