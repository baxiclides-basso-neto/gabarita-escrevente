import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion, useInView, useAnimation, AnimatePresence } from 'framer-motion';
import { 
  BookOpen, 
  BarChart3, 
  Target, 
  CheckCircle, 
  ArrowRight, 
  Scale,
  FileText,
  Clock,
  Users,
  Award,
  X,
  Lock
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { questoes, type Questao } from '@/data/questoes';

function AnimatedSection({ children, delay = 0 }: { children: React.ReactNode; delay?: number }) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });
  const controls = useAnimation();

  useEffect(() => {
    if (isInView) {
      controls.start('visible');
    }
  }, [isInView, controls]);

  return (
    <motion.div
      ref={ref}
      initial="hidden"
      animate={controls}
      variants={{
        hidden: { opacity: 0, y: 50 },
        visible: { opacity: 1, y: 0, transition: { duration: 0.6, delay } }
      }}
    >
      {children}
    </motion.div>
  );
}

function StatCounter({ value, label, suffix = '' }: { value: number; label: string; suffix?: string }) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });
  
  return (
    <div ref={ref} className="text-center">
      <div className="text-4xl md:text-5xl font-bold text-[#c9a227] mb-2">
        {isInView ? (
          <motion.span
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
          >
            {value}{suffix}
          </motion.span>
        ) : '0'}
      </div>
      <p className="text-gray-400">{label}</p>
    </div>
  );
}

// Modal de Questão
function QuestionModal({ 
  isOpen, 
  onClose, 
  questao, 
  onAnswer,
  showFeedback,
  selectedAnswer
}: { 
  isOpen: boolean;
  onClose: () => void;
  questao: Questao | null;
  onAnswer: (letra: string) => void;
  showFeedback: boolean;
  selectedAnswer: string | null;
}) {
  if (!isOpen || !questao) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center p-4"
      >
        {/* Backdrop */}
        <div 
          className="absolute inset-0 bg-black/80 backdrop-blur-sm"
          onClick={onClose}
        />
        
        {/* Modal */}
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="relative bg-[#1e293b] rounded-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto border border-white/10"
        >
          {/* Header */}
          <div className="sticky top-0 bg-[#1e293b] border-b border-white/10 p-4 flex items-center justify-between z-10">
            <div className="flex items-center space-x-3">
              <Badge variant="outline" className="bg-blue-500/20 text-blue-400 border-blue-500/30">
                {questao.topico}
              </Badge>
              <Badge variant="outline" className="bg-purple-500/20 text-purple-400 border-purple-500/30">
                {questao.artigos[0]}
              </Badge>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-lg hover:bg-white/5 text-gray-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Content */}
          <div className="p-6">
            {/* Question */}
            <div className="bg-[#0f172a] rounded-xl p-6 border border-white/5 mb-6">
              <p className="text-white text-lg leading-relaxed whitespace-pre-line">
                {questao.enunciado}
              </p>
            </div>

            {/* Alternatives */}
            <div className="space-y-3">
              <p className="text-gray-400 text-sm mb-4">Selecione a alternativa correta:</p>
              {questao.alternativas.map((alt, index) => {
                const isSelected = selectedAnswer === alt.letra;
                const isCorrect = alt.correta;
                
                let buttonClass = 'bg-[#0f172a] border-white/10 text-white hover:bg-white/5 hover:border-[#c9a227]/50';
                
                if (showFeedback) {
                  if (isCorrect) {
                    buttonClass = 'bg-green-500/20 border-green-500 text-green-400';
                  } else if (isSelected && !isCorrect) {
                    buttonClass = 'bg-red-500/20 border-red-500 text-red-400';
                  } else {
                    buttonClass = 'bg-[#0f172a] border-white/5 text-gray-500';
                  }
                } else if (isSelected) {
                  buttonClass = 'bg-[#c9a227]/20 border-[#c9a227] text-[#c9a227]';
                }

                return (
                  <motion.button
                    key={alt.letra}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                    onClick={() => !showFeedback && onAnswer(alt.letra)}
                    disabled={showFeedback}
                    className={`w-full text-left p-4 rounded-xl border-2 transition-all duration-200 ${buttonClass}`}
                  >
                    <div className="flex items-start space-x-4">
                      <span className={`flex-shrink-0 w-8 h-8 rounded-lg flex items-center justify-center font-bold text-sm ${
                        showFeedback 
                          ? isCorrect 
                            ? 'bg-green-500 text-white'
                            : isSelected 
                              ? 'bg-red-500 text-white'
                              : 'bg-white/10 text-gray-500'
                          : isSelected
                            ? 'bg-[#c9a227] text-[#0f172a]'
                            : 'bg-white/10 text-gray-400'
                      }`}>
                        {alt.letra}
                      </span>
                      <span className="flex-1 pt-1">{alt.texto}</span>
                      {showFeedback && isCorrect && (
                        <CheckCircle className="w-6 h-6 text-green-500 flex-shrink-0" />
                      )}
                      {showFeedback && isSelected && !isCorrect && (
                        <X className="w-6 h-6 text-red-500 flex-shrink-0" />
                      )}
                    </div>
                  </motion.button>
                );
              })}
            </div>

            {/* Feedback */}
            <AnimatePresence>
              {showFeedback && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="mt-6 bg-[#0f172a] rounded-xl border border-white/5 overflow-hidden"
                >
                  <div className="p-6">
                    <h4 className="text-lg font-bold text-white mb-4 flex items-center">
                      <BarChart3 className="w-5 h-5 mr-2 text-[#c9a227]" />
                      Justificativas
                    </h4>
                    <div className="space-y-3">
                      {questao.alternativas.map((alt, index) => (
                        <motion.div
                          key={alt.letra}
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: index * 0.1 }}
                          className={`p-4 rounded-lg ${
                            alt.correta 
                              ? 'bg-green-500/10 border border-green-500/30' 
                              : 'bg-white/5 border border-white/5'
                          }`}
                        >
                          <div className="flex items-start space-x-3">
                            <span className={`flex-shrink-0 w-6 h-6 rounded flex items-center justify-center text-sm font-bold ${
                              alt.correta ? 'bg-green-500 text-white' : 'bg-white/10 text-gray-500'
                            }`}>
                              {alt.letra}
                            </span>
                            <p className={`text-sm ${alt.correta ? 'text-green-400' : 'text-gray-400'}`}>
                              {alt.justificativa}
                            </p>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}

// Preview Questions Section
function PreviewQuestions() {
  const [selectedQuestion, setSelectedQuestion] = useState<Questao | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [showFeedback, setShowFeedback] = useState<Record<number, boolean>>({});

  // Primeiras 3 questões para preview
  const previewQuestoes = questoes.slice(0, 3);

  const handleOpenQuestion = (questao: Questao) => {
    setSelectedQuestion(questao);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setSelectedQuestion(null);
  };

  const handleAnswer = (letra: string) => {
    if (selectedQuestion) {
      setAnswers(prev => ({ ...prev, [selectedQuestion.id]: letra }));
      setShowFeedback(prev => ({ ...prev, [selectedQuestion.id]: true }));
    }
  };

  return (
    <section className="py-24 bg-[#1e293b]/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <AnimatedSection>
          <div className="text-center mb-12">
            <span className="text-[#c9a227] font-medium">Experimente Grátis</span>
            <h2 className="text-3xl md:text-4xl font-bold text-white mt-2">
              3 Questões para Testar
            </h2>
            <p className="text-gray-400 mt-4 max-w-2xl mx-auto">
              Resolva 3 questões gratuitamente. Para acessar todas as 25+ questões, faça login ou cadastre-se.
            </p>
          </div>
        </AnimatedSection>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {previewQuestoes.map((questao, index) => {
            const hasAnswered = showFeedback[questao.id];
            const isCorrect = hasAnswered && answers[questao.id] === questao.alternativas.find(a => a.correta)?.letra;

            return (
              <AnimatedSection key={questao.id} delay={index * 0.1}>
                <motion.div
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => handleOpenQuestion(questao)}
                  className="cursor-pointer"
                >
                  <Card className={`bg-[#1e293b] border-white/5 hover:border-[#c9a227]/30 transition-all duration-300 h-full ${
                    hasAnswered ? (isCorrect ? 'border-green-500/30' : 'border-red-500/30') : ''
                  }`}>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <Badge variant="outline" className="bg-blue-500/20 text-blue-400 border-blue-500/30">
                          {questao.topico}
                        </Badge>
                        {hasAnswered && (
                          isCorrect ? (
                            <CheckCircle className="w-5 h-5 text-green-500" />
                          ) : (
                            <X className="w-5 h-5 text-red-500" />
                          )
                        )}
                      </div>
                      <p className="text-white line-clamp-3 mb-4">
                        {questao.enunciado.substring(0, 150)}...
                      </p>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-500">{questao.artigos[0]}</span>
                        <Button size="sm" variant="outline" className="border-[#c9a227]/30 text-[#c9a227]">
                          Responder
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              </AnimatedSection>
            );
          })}
        </div>

        {/* Locked Content */}
        <AnimatedSection delay={0.3}>
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-t from-[#0f172a] via-[#0f172a]/80 to-transparent z-10" />
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 opacity-30">
              {[1, 2, 3].map((i) => (
                <Card key={i} className="bg-[#1e293b] border-white/5">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="w-20 h-6 bg-white/10 rounded" />
                      <Lock className="w-5 h-5 text-gray-500" />
                    </div>
                    <div className="space-y-2">
                      <div className="h-4 bg-white/10 rounded w-full" />
                      <div className="h-4 bg-white/10 rounded w-4/5" />
                      <div className="h-4 bg-white/10 rounded w-3/5" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
            
            {/* CTA Overlay */}
            <div className="absolute inset-0 z-20 flex items-center justify-center">
              <div className="text-center">
                <Lock className="w-12 h-12 text-[#c9a227] mx-auto mb-4" />
                <h3 className="text-2xl font-bold text-white mb-2">
                  +22 Questões Exclusivas
                </h3>
                <p className="text-gray-400 mb-6">
                  Cadastre-se gratuitamente para desbloquear todo o conteúdo
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Link to="/cadastro">
                    <Button className="bg-gradient-to-r from-[#c9a227] to-[#a88a1f] text-[#0f172a] font-semibold px-8">
                      Criar Conta Grátis
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  </Link>
                  <Link to="/login">
                    <Button variant="outline" className="border-white/20 text-white hover:bg-white/5">
                      Já tenho conta
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </AnimatedSection>
      </div>

      {/* Question Modal */}
      <QuestionModal
        isOpen={isModalOpen}
        onClose={handleCloseModal}
        questao={selectedQuestion}
        onAnswer={handleAnswer}
        showFeedback={selectedQuestion ? showFeedback[selectedQuestion.id] || false : false}
        selectedAnswer={selectedQuestion ? answers[selectedQuestion.id] || null : null}
      />
    </section>
  );
}

export function LandingPage() {
  return (
    <div className="min-h-screen bg-[#0f172a]">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Background */}
        <div className="absolute inset-0 bg-gradient-to-br from-[#0f172a] via-[#1e3a5f] to-[#0f172a]" />
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1589829545856-d10d557cf95f?auto=format&fit=crop&q=80')] bg-cover bg-center opacity-10" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0f172a] via-transparent to-transparent" />
        
        {/* Content */}
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32">
          <div className="text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <span className="inline-flex items-center px-4 py-2 rounded-full bg-[#c9a227]/10 border border-[#c9a227]/30 text-[#c9a227] text-sm font-medium mb-6">
                <Scale className="w-4 h-4 mr-2" />
                Prepare-se para o TJSP
              </span>
            </motion.div>
            
            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="text-4xl md:text-6xl lg:text-7xl font-bold text-white mb-6 leading-tight"
            >
              <span className="text-[#c9a227]">Gabarita</span>Escrevente
            </motion.h1>
            
            <motion.p
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-xl text-gray-400 max-w-2xl mx-auto mb-10"
            >
              Questões de Processo Civil no estilo Vunesp com casos concretos e justificativas completas. 
              Estude com conteúdo alinhado ao último edital do concurso de Escrevente do TJSP.
            </motion.p>
            
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="flex flex-col sm:flex-row items-center justify-center gap-4"
            >
              <Link to="/cadastro">
                <Button size="lg" className="bg-gradient-to-r from-[#c9a227] to-[#a88a1f] text-[#0f172a] font-semibold px-8 py-6 text-lg hover:from-[#d4b43a] hover:to-[#c9a227] group">
                  Começar Agora
                  <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                </Button>
              </Link>
              <Link to="/questoes">
                <Button size="lg" variant="outline" className="border-white/20 text-white hover:bg-white/5 px-8 py-6 text-lg">
                  Ver Questões
                </Button>
              </Link>
            </motion.div>
            
            {/* Features mini */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="mt-16 flex flex-wrap items-center justify-center gap-6"
            >
              {[
                { icon: CheckCircle, text: '25+ Questões' },
                { icon: CheckCircle, text: 'Justificativas Completas' },
                { icon: CheckCircle, text: 'Estilo Vunesp' },
              ].map((item, index) => (
                <div key={index} className="flex items-center space-x-2 text-gray-400">
                  <item.icon className="w-5 h-5 text-[#c9a227]" />
                  <span>{item.text}</span>
                </div>
              ))}
            </motion.div>
          </div>
        </div>
        
        {/* Scroll indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          className="absolute bottom-8 left-1/2 -translate-x-1/2"
        >
          <div className="w-6 h-10 rounded-full border-2 border-white/20 flex items-start justify-center p-2">
            <motion.div
              animate={{ y: [0, 12, 0] }}
              transition={{ duration: 1.5, repeat: Infinity }}
              className="w-1.5 h-1.5 rounded-full bg-[#c9a227]"
            />
          </div>
        </motion.div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-[#1e293b]/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <AnimatedSection>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              <StatCounter value={25} label="Questões" suffix="+" />
              <StatCounter value={9} label="Tópicos" />
              <StatCounter value={100} label="Justificativas" suffix="%" />
              <StatCounter value={40} label="Artigos CPC" suffix="+" />
            </div>
          </AnimatedSection>
        </div>
      </section>

      {/* Preview Questions Section */}
      <PreviewQuestions />

      {/* Features Section */}
      <section id="features" className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <AnimatedSection>
            <div className="text-center mb-16">
              <span className="text-[#c9a227] font-medium">Recursos</span>
              <h2 className="text-3xl md:text-4xl font-bold text-white mt-2">
                Tudo que você precisa para aprovar
              </h2>
              <p className="text-gray-400 mt-4 max-w-2xl mx-auto">
                Nossa plataforma foi desenvolvida especificamente para o concurso de Escrevente do TJSP
              </p>
            </div>
          </AnimatedSection>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                icon: BookOpen,
                title: 'Questões Estilo Vunesp',
                description: 'Casos concretos e questões diretas no mesmo formato da banca organizadora do TJSP.',
                color: 'from-blue-500 to-blue-600'
              },
              {
                icon: BarChart3,
                title: 'Acompanhe seu Progresso',
                description: 'Dashboard completo com estatísticas de acertos, tempo de estudo e evolução por tópico.',
                color: 'from-[#c9a227] to-[#a88a1f]'
              },
              {
                icon: Target,
                title: 'Foco no Edital',
                description: 'Conteúdo alinhado ao último edital: arts. 144-155, 188-275, 294-311, 318-538, 994-1026 CPC.',
                color: 'from-green-500 to-green-600'
              }
            ].map((feature, index) => (
              <AnimatedSection key={index} delay={index * 0.1}>
                <Card className="bg-[#1e293b] border-white/5 hover:border-[#c9a227]/30 transition-all duration-300 group h-full">
                  <CardContent className="p-8">
                    <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${feature.color} flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}>
                      <feature.icon className="w-7 h-7 text-white" />
                    </div>
                    <h3 className="text-xl font-bold text-white mb-3">{feature.title}</h3>
                    <p className="text-gray-400">{feature.description}</p>
                  </CardContent>
                </Card>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section id="how-it-works" className="py-24 bg-[#1e293b]/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <AnimatedSection>
            <div className="text-center mb-16">
              <span className="text-[#c9a227] font-medium">Como Funciona</span>
              <h2 className="text-3xl md:text-4xl font-bold text-white mt-2">
                Estude em 3 passos simples
              </h2>
            </div>
          </AnimatedSection>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                step: '01',
                icon: Users,
                title: 'Crie sua conta',
                description: 'Cadastre-se gratuitamente e tenha acesso a todas as questões da plataforma.'
              },
              {
                step: '02',
                icon: FileText,
                title: 'Resolva questões',
                description: 'Pratique com questões no estilo Vunesp, com casos concretos e justificativas completas.'
              },
              {
                step: '03',
                icon: Award,
                title: 'Acompanhe sua evolução',
                description: 'Monitore seu progresso, identifique pontos fracos e melhore seu desempenho.'
              }
            ].map((item, index) => (
              <AnimatedSection key={index} delay={index * 0.1}>
                <div className="relative">
                  <div className="text-6xl font-bold text-[#c9a227]/10 absolute -top-4 -left-2">
                    {item.step}
                  </div>
                  <div className="relative pt-8">
                    <div className="w-16 h-16 rounded-xl bg-[#c9a227]/10 flex items-center justify-center mb-6">
                      <item.icon className="w-8 h-8 text-[#c9a227]" />
                    </div>
                    <h3 className="text-xl font-bold text-white mb-3">{item.title}</h3>
                    <p className="text-gray-400">{item.description}</p>
                  </div>
                </div>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>

      {/* Content Coverage Section */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <AnimatedSection>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div>
                <span className="text-[#c9a227] font-medium">Conteúdo Programático</span>
                <h2 className="text-3xl md:text-4xl font-bold text-white mt-2 mb-6">
                  Tudo que cai no edital do TJSP
                </h2>
                <p className="text-gray-400 mb-8">
                  Nossas questões cobrem todos os artigos do Código de Processo Civil exigidos no último edital para o cargo de Escrevente.
                </p>
                
                <div className="space-y-4">
                  {[
                    { icon: Scale, text: 'Impedimento e Suspeição (Arts. 144-155 CPC)' },
                    { icon: Clock, text: 'Atos Processuais e Prazos (Arts. 188-275 CPC)' },
                    { icon: FileText, text: 'Tutela Provisória (Arts. 294-311 CPC)' },
                    { icon: BookOpen, text: 'Procedimento Comum (Arts. 318-538 CPC)' },
                    { icon: Target, text: 'Recursos - Apelação (Arts. 994-1026 CPC)' },
                    { icon: Scale, text: 'Juizados Especiais (Leis 9.099/95 e 12.153/2009)' },
                  ].map((item, index) => (
                    <div key={index} className="flex items-center space-x-3">
                      <div className="w-10 h-10 rounded-lg bg-[#c9a227]/10 flex items-center justify-center flex-shrink-0">
                        <item.icon className="w-5 h-5 text-[#c9a227]" />
                      </div>
                      <span className="text-gray-300">{item.text}</span>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-br from-[#c9a227]/20 to-[#1e3a5f]/20 rounded-2xl blur-3xl" />
                <div className="relative bg-[#1e293b] rounded-2xl p-8 border border-white/5">
                  <div className="flex items-center justify-between mb-6">
                    <span className="text-gray-400">Progresso de Estudos</span>
                    <span className="text-[#c9a227] font-bold">0%</span>
                  </div>
                  <div className="space-y-4">
                    {[
                      { label: 'Impedimento e Suspeição', progress: 0 },
                      { label: 'Atos Processuais', progress: 0 },
                      { label: 'Tutela Provisória', progress: 0 },
                      { label: 'Procedimento Comum', progress: 0 },
                      { label: 'Recursos', progress: 0 },
                    ].map((item, index) => (
                      <div key={index}>
                        <div className="flex justify-between text-sm mb-1">
                          <span className="text-gray-400">{item.label}</span>
                          <span className="text-gray-500">{item.progress}%</span>
                        </div>
                        <div className="h-2 bg-white/5 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-gradient-to-r from-[#c9a227] to-[#a88a1f] rounded-full"
                            style={{ width: `${item.progress}%` }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                  <Link to="/cadastro">
                    <Button className="w-full mt-6 bg-gradient-to-r from-[#c9a227] to-[#a88a1f] text-[#0f172a] font-semibold">
                      Começar a Estudar
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          </AnimatedSection>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-gradient-to-br from-[#1e3a5f]/50 to-[#0f172a]">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <AnimatedSection>
            <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">
              Pronto para conquistar sua <span className="text-[#c9a227]">aprovação</span>?
            </h2>
            <p className="text-xl text-gray-400 mb-10">
              Junte-se a milhares de candidatos que estão se preparando para o TJSP com nossa plataforma.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link to="/cadastro">
                <Button size="lg" className="bg-gradient-to-r from-[#c9a227] to-[#a88a1f] text-[#0f172a] font-semibold px-8 py-6 text-lg">
                  Criar Conta Grátis
                </Button>
              </Link>
              <Link to="/questoes">
                <Button size="lg" variant="outline" className="border-white/20 text-white hover:bg-white/5 px-8 py-6 text-lg">
                  Explorar Questões
                </Button>
              </Link>
            </div>
          </AnimatedSection>
        </div>
      </section>
    </div>
  );
}
