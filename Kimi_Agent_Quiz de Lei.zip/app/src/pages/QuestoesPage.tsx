import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  BookOpen, 
  CheckCircle, 
  XCircle,
  ArrowRight, 
  ArrowLeft,
  Filter,
  RotateCcw,
  Scale,
  BarChart3,
  Home
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useAuth } from '@/hooks/useAuth';
import { useQuiz } from '@/hooks/useQuiz';
import { topicos, type Questao } from '@/data/questoes';

function QuestionCard({ 
  questao, 
  selectedAnswer, 
  showFeedback, 
  onSelect 
}: { 
  questao: Questao; 
  selectedAnswer: string | null;
  showFeedback: boolean;
  onSelect: (letra: string) => void;
}) {
  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'facil': return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'media': return 'bg-[#c9a227]/20 text-[#c9a227] border-[#c9a227]/30';
      case 'dificil': return 'bg-red-500/20 text-red-400 border-red-500/30';
      default: return 'bg-gray-500/20 text-gray-400';
    }
  };

  const getDifficultyLabel = (difficulty: string) => {
    switch (difficulty) {
      case 'facil': return 'Fácil';
      case 'media': return 'Média';
      case 'dificil': return 'Difícil';
      default: return difficulty;
    }
  };

  return (
    <div className="space-y-6">
      {/* Question Header */}
      <div className="flex flex-wrap items-center gap-3 mb-4">
        <Badge variant="outline" className={getDifficultyColor(questao.dificuldade)}>
          {getDifficultyLabel(questao.dificuldade)}
        </Badge>
        <Badge variant="outline" className="bg-blue-500/20 text-blue-400 border-blue-500/30">
          {questao.topico}
        </Badge>
        <Badge variant="outline" className="bg-purple-500/20 text-purple-400 border-purple-500/30">
          {questao.artigos.join(', ')}
        </Badge>
      </div>

      {/* Question Type */}
      <div className="flex items-center space-x-2 text-sm text-gray-400">
        {questao.tipo === 'caso_concreto' ? (
          <>
            <Scale className="w-4 h-4" />
            <span>Caso Concreto</span>
          </>
        ) : (
          <>
            <BookOpen className="w-4 h-4" />
            <span>Questão Direta</span>
          </>
        )}
      </div>

      {/* Question Text */}
      <div className="bg-[#0f172a] rounded-xl p-6 border border-white/5">
        <p className="text-white text-lg leading-relaxed whitespace-pre-line">
          {questao.enunciado}
        </p>
      </div>

      {/* Alternatives */}
      <div className="space-y-3">
        <p className="text-gray-400 text-sm mb-4">Selecione a alternativa correta:</p>
        {questao.alternativas.map((alt, index) => {
          const isSelected = selectedAnswer === alt.letra;
          const isCorrect = alt.correta;
          
          let buttonClass = 'bg-[#0f172a] border-white/10 text-white hover:bg-white/5 hover:border-[#c9a227]/50';
          
          if (showFeedback) {
            if (isCorrect) {
              buttonClass = 'bg-green-500/20 border-green-500 text-green-400';
            } else if (isSelected && !isCorrect) {
              buttonClass = 'bg-red-500/20 border-red-500 text-red-400';
            } else {
              buttonClass = 'bg-[#0f172a] border-white/5 text-gray-500';
            }
          } else if (isSelected) {
            buttonClass = 'bg-[#c9a227]/20 border-[#c9a227] text-[#c9a227]';
          }

          return (
            <motion.button
              key={alt.letra}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              onClick={() => !showFeedback && onSelect(alt.letra)}
              disabled={showFeedback}
              className={`w-full text-left p-4 rounded-xl border-2 transition-all duration-200 ${buttonClass}`}
            >
              <div className="flex items-start space-x-4">
                <span className={`flex-shrink-0 w-8 h-8 rounded-lg flex items-center justify-center font-bold text-sm ${
                  showFeedback 
                    ? isCorrect 
                      ? 'bg-green-500 text-white'
                      : isSelected 
                        ? 'bg-red-500 text-white'
                        : 'bg-white/10 text-gray-500'
                    : isSelected
                      ? 'bg-[#c9a227] text-[#0f172a]'
                      : 'bg-white/10 text-gray-400'
                }`}>
                  {alt.letra}
                </span>
                <span className="flex-1 pt-1">{alt.texto}</span>
                {showFeedback && isCorrect && (
                  <CheckCircle className="w-6 h-6 text-green-500 flex-shrink-0" />
                )}
                {showFeedback && isSelected && !isCorrect && (
                  <XCircle className="w-6 h-6 text-red-500 flex-shrink-0" />
                )}
              </div>
            </motion.button>
          );
        })}
      </div>

      {/* Feedback */}
      <AnimatePresence>
        {showFeedback && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="bg-[#0f172a] rounded-xl border border-white/5 overflow-hidden"
          >
            <div className="p-6">
              <h4 className="text-lg font-bold text-white mb-4 flex items-center">
                <BarChart3 className="w-5 h-5 mr-2 text-[#c9a227]" />
                Justificativas
              </h4>
              <div className="space-y-4">
                {questao.alternativas.map((alt, index) => (
                  <motion.div
                    key={alt.letra}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className={`p-4 rounded-lg ${
                      alt.correta 
                        ? 'bg-green-500/10 border border-green-500/30' 
                        : 'bg-white/5 border border-white/5'
                    }`}
                  >
                    <div className="flex items-start space-x-3">
                      <span className={`flex-shrink-0 w-6 h-6 rounded flex items-center justify-center text-sm font-bold ${
                        alt.correta ? 'bg-green-500 text-white' : 'bg-white/10 text-gray-500'
                      }`}>
                        {alt.letra}
                      </span>
                      <div>
                        <p className={`text-sm ${alt.correta ? 'text-green-400 font-medium' : 'text-gray-400'}`}>
                          {alt.justificativa}
                        </p>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function ResultsView({ 
  results, 
  onRestart 
}: { 
  results: { total: number; correct: number; percentage: number };
  onRestart: () => void;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="max-w-2xl mx-auto"
    >
      <Card className="bg-[#1e293b] border-white/5">
        <CardContent className="p-8 text-center">
          <div className="w-24 h-24 rounded-full bg-gradient-to-br from-[#c9a227] to-[#a88a1f] flex items-center justify-center mx-auto mb-6">
            <BarChart3 className="w-12 h-12 text-[#0f172a]" />
          </div>
          
          <h2 className="text-3xl font-bold text-white mb-2">Resultado do Simulado</h2>
          <p className="text-gray-400 mb-8">Você completou todas as questões!</p>
          
          <div className="grid grid-cols-3 gap-6 mb-8">
            <div className="bg-[#0f172a] rounded-xl p-4">
              <p className="text-3xl font-bold text-white">{results.total}</p>
              <p className="text-gray-400 text-sm">Questões</p>
            </div>
            <div className="bg-[#0f172a] rounded-xl p-4">
              <p className="text-3xl font-bold text-green-400">{results.correct}</p>
              <p className="text-gray-400 text-sm">Acertos</p>
            </div>
            <div className="bg-[#0f172a] rounded-xl p-4">
              <p className={`text-3xl font-bold ${
                results.percentage >= 70 ? 'text-green-400' : 
                results.percentage >= 50 ? 'text-[#c9a227]' : 'text-red-400'
              }`}>
                {results.percentage}%
              </p>
              <p className="text-gray-400 text-sm">Aproveitamento</p>
            </div>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              onClick={onRestart}
              className="bg-gradient-to-r from-[#c9a227] to-[#a88a1f] text-[#0f172a] font-semibold"
            >
              <RotateCcw className="w-4 h-4 mr-2" />
              Novo Simulado
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

function FilterView({ onStart }: { onStart: (topic: string | null, difficulty: string | null) => void }) {
  const [selectedTopic, setSelectedTopic] = useState<string>('all');
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>('all');

  const handleStart = () => {
    onStart(
      selectedTopic === 'all' ? null : selectedTopic,
      selectedDifficulty === 'all' ? null : selectedDifficulty
    );
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-2xl mx-auto"
    >
      <Card className="bg-[#1e293b] border-white/5">
        <CardContent className="p-8">
          <div className="text-center mb-8">
            <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-[#c9a227] to-[#a88a1f] flex items-center justify-center mx-auto mb-4">
              <Filter className="w-8 h-8 text-[#0f172a]" />
            </div>
            <h2 className="text-2xl font-bold text-white mb-2">Configurar Simulado</h2>
            <p className="text-gray-400">Escolha os filtros para personalizar seu estudo</p>
          </div>

          <div className="space-y-6">
            <div>
              <label className="text-gray-300 text-sm mb-2 block">Tópico</label>
              <Select value={selectedTopic} onValueChange={setSelectedTopic}>
                <SelectTrigger className="bg-[#0f172a] border-white/10 text-white">
                  <SelectValue placeholder="Selecione um tópico" />
                </SelectTrigger>
                <SelectContent className="bg-[#1e293b] border-white/10">
                  <SelectItem value="all">Todos os tópicos</SelectItem>
                  {topicos.map((topico) => (
                    <SelectItem key={topico.id} value={topico.nome}>
                      {topico.nome}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-gray-300 text-sm mb-2 block">Dificuldade</label>
              <Select value={selectedDifficulty} onValueChange={setSelectedDifficulty}>
                <SelectTrigger className="bg-[#0f172a] border-white/10 text-white">
                  <SelectValue placeholder="Selecione a dificuldade" />
                </SelectTrigger>
                <SelectContent className="bg-[#1e293b] border-white/10">
                  <SelectItem value="all">Todas as dificuldades</SelectItem>
                  <SelectItem value="facil">Fácil</SelectItem>
                  <SelectItem value="media">Média</SelectItem>
                  <SelectItem value="dificil">Difícil</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Button 
              onClick={handleStart}
              className="w-full bg-gradient-to-r from-[#c9a227] to-[#a88a1f] text-[#0f172a] font-semibold py-6"
            >
              <BookOpen className="w-5 h-5 mr-2" />
              Iniciar Simulado
            </Button>
          </div>

          <div className="mt-8 pt-6 border-t border-white/5">
            <p className="text-gray-500 text-sm text-center mb-4">Tópicos disponíveis:</p>
            <div className="flex flex-wrap gap-2 justify-center">
              {topicos.map((topico) => (
                <Badge 
                  key={topico.id}
                  variant="outline" 
                  className="bg-white/5 text-gray-400 border-white/10"
                >
                  {topico.nome}
                </Badge>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}

export function QuestoesPage() {
  const { updateProgress } = useAuth();
  const { 
    filteredQuestions, 
    currentQuestionIndex, 
    answers, 
    showFeedback, 
    isFinished,
    startQuiz,
    answerQuestion,
    nextQuestion,
    previousQuestion,
    finishQuiz,
    resetQuiz,
    getCurrentQuestion,
    getResults
  } = useQuiz();

  const [hasStarted, setHasStarted] = useState(false);

  useEffect(() => {
    if (filteredQuestions.length === 0 && !hasStarted) {
      // Show filter view if no questions loaded yet
    }
  }, [filteredQuestions, hasStarted]);

  const handleStart = (topic: string | null, difficulty: string | null) => {
    startQuiz(topic, difficulty);
    setHasStarted(true);
  };

  const handleAnswer = (letra: string) => {
    const currentQuestion = getCurrentQuestion();
    if (currentQuestion) {
      answerQuestion(currentQuestion.id, letra);
      
      // Check if correct and update progress
      const isCorrect = currentQuestion.alternativas.find(a => a.letra === letra)?.correta || false;
      updateProgress(currentQuestion.id, isCorrect, currentQuestion.topico);
    }
  };

  const handleNext = () => {
    if (currentQuestionIndex < filteredQuestions.length - 1) {
      nextQuestion();
    } else {
      finishQuiz();
    }
  };

  const handleRestart = () => {
    resetQuiz();
    setHasStarted(false);
  };

  const currentQuestion = getCurrentQuestion();
  const results = getResults();

  if (!hasStarted) {
    return (
      <div className="min-h-screen bg-[#0f172a] pt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <FilterView onStart={handleStart} />
        </div>
      </div>
    );
  }

  if (isFinished) {
    return (
      <div className="min-h-screen bg-[#0f172a] pt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <ResultsView results={results} onRestart={handleRestart} />
        </div>
      </div>
    );
  }

  if (!currentQuestion) {
    return (
      <div className="min-h-screen bg-[#0f172a] pt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Card className="bg-[#1e293b] border-white/5">
            <CardContent className="p-8 text-center">
              <p className="text-gray-400">Nenhuma questão encontrada com os filtros selecionados.</p>
              <Button 
                onClick={handleRestart}
                className="mt-4 bg-gradient-to-r from-[#c9a227] to-[#a88a1f] text-[#0f172a]"
              >
                Voltar aos Filtros
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0f172a] pt-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Back Button */}
        <div className="mb-6">
          <button
            onClick={() => window.location.href = '/dashboard'}
            className="flex items-center space-x-2 text-gray-400 hover:text-white transition-colors"
          >
            <Home className="w-5 h-5" />
            <span>Voltar ao Dashboard</span>
          </button>
        </div>
        
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="text-gray-400 text-sm">
              Questão {currentQuestionIndex + 1} de {filteredQuestions.length}
            </span>
            <span className="text-gray-400 text-sm">
              {Math.round(((currentQuestionIndex + 1) / filteredQuestions.length) * 100)}%
            </span>
          </div>
          <div className="h-2 bg-white/5 rounded-full overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${((currentQuestionIndex + 1) / filteredQuestions.length) * 100}%` }}
              className="h-full bg-gradient-to-r from-[#c9a227] to-[#a88a1f] rounded-full"
            />
          </div>
        </div>

        {/* Question Card */}
        <motion.div
          key={currentQuestion.id}
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -50 }}
          transition={{ duration: 0.3 }}
        >
          <Card className="bg-[#1e293b] border-white/5">
            <CardContent className="p-6 md:p-8">
              <QuestionCard
                questao={currentQuestion}
                selectedAnswer={answers[currentQuestion.id] || null}
                showFeedback={showFeedback}
                onSelect={handleAnswer}
              />
            </CardContent>
          </Card>
        </motion.div>

        {/* Navigation */}
        <div className="flex items-center justify-between mt-8">
          <Button
            variant="outline"
            onClick={previousQuestion}
            disabled={currentQuestionIndex === 0}
            className="border-white/20 text-white hover:bg-white/5 disabled:opacity-50"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Anterior
          </Button>

          {showFeedback ? (
            <Button
              onClick={handleNext}
              className="bg-gradient-to-r from-[#c9a227] to-[#a88a1f] text-[#0f172a] font-semibold"
            >
              {currentQuestionIndex < filteredQuestions.length - 1 ? (
                <>
                  Próxima
                  <ArrowRight className="w-4 h-4 ml-2" />
                </>
              ) : (
                <>
                  Finalizar
                  <CheckCircle className="w-4 h-4 ml-2" />
                </>
              )}
            </Button>
          ) : (
            <div className="text-gray-500 text-sm">
              Selecione uma alternativa para continuar
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

