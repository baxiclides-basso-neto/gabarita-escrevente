import { createContext, useContext, useState, useCallback, type ReactNode } from 'react';

interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
}

interface UserProgress {
  questionsAnswered: number;
  correctAnswers: number;
  streakDays: number;
  lastStudyDate: string | null;
  topicProgress: Record<string, { answered: number; correct: number }>;
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  progress: UserProgress;
  login: (email: string, password: string) => Promise<boolean>;
  register: (name: string, email: string, password: string) => Promise<boolean>;
  logout: () => void;
  updateProgress: (questionId: number, isCorrect: boolean, topic: string) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('tjsp_user');
    return saved ? JSON.parse(saved) : null;
  });

  const [progress, setProgress] = useState<UserProgress>(() => {
    const saved = localStorage.getItem('tjsp_progress');
    return saved ? JSON.parse(saved) : {
      questionsAnswered: 0,
      correctAnswers: 0,
      streakDays: 0,
      lastStudyDate: null,
      topicProgress: {}
    };
  });

  const login = useCallback(async (email: string, password: string): Promise<boolean> => {
    // Simulação de login - em produção, isso seria uma API call
    const users = JSON.parse(localStorage.getItem('tjsp_users') || '[]');
    const foundUser = users.find((u: any) => u.email === email && u.password === password);
    
    if (foundUser) {
      const { password, ...userWithoutPassword } = foundUser;
      setUser(userWithoutPassword);
      localStorage.setItem('tjsp_user', JSON.stringify(userWithoutPassword));
      
      // Atualiza streak
      const today = new Date().toISOString().split('T')[0];
      const lastDate = progress.lastStudyDate;
      
      if (lastDate) {
        const last = new Date(lastDate);
        const todayDate = new Date(today);
        const diffDays = Math.floor((todayDate.getTime() - last.getTime()) / (1000 * 60 * 60 * 24));
        
        if (diffDays === 1) {
          setProgress(prev => ({ ...prev, streakDays: prev.streakDays + 1 }));
        } else if (diffDays > 1) {
          setProgress(prev => ({ ...prev, streakDays: 1 }));
        }
      }
      
      return true;
    }
    return false;
  }, [progress.lastStudyDate]);

  const register = useCallback(async (name: string, email: string, password: string): Promise<boolean> => {
    // Simulação de registro - em produção, isso seria uma API call
    const users = JSON.parse(localStorage.getItem('tjsp_users') || '[]');
    
    if (users.find((u: any) => u.email === email)) {
      return false;
    }
    
    const newUser = {
      id: Date.now().toString(),
      name,
      email,
      password,
      avatar: `https://api.dicebear.com/7.x/initials/svg?seed=${name}&backgroundColor=1e3a5f&textColor=c9a227`
    };
    
    users.push(newUser);
    localStorage.setItem('tjsp_users', JSON.stringify(users));
    
    const { password: _, ...userWithoutPassword } = newUser;
    setUser(userWithoutPassword);
    localStorage.setItem('tjsp_user', JSON.stringify(userWithoutPassword));
    
    return true;
  }, []);

  const logout = useCallback(() => {
    setUser(null);
    localStorage.removeItem('tjsp_user');
  }, []);

  const updateProgress = useCallback((_questionId: number, isCorrect: boolean, topic: string) => {
    setProgress(prev => {
      const today = new Date().toISOString().split('T')[0];
      const topicProg = prev.topicProgress[topic] || { answered: 0, correct: 0 };
      
      const newProgress = {
        questionsAnswered: prev.questionsAnswered + 1,
        correctAnswers: isCorrect ? prev.correctAnswers + 1 : prev.correctAnswers,
        streakDays: prev.lastStudyDate === today ? prev.streakDays : prev.streakDays + 1,
        lastStudyDate: today,
        topicProgress: {
          ...prev.topicProgress,
          [topic]: {
            answered: topicProg.answered + 1,
            correct: isCorrect ? topicProg.correct + 1 : topicProg.correct
          }
        }
      };
      
      localStorage.setItem('tjsp_progress', JSON.stringify(newProgress));
      return newProgress;
    });
  }, []);

  return (
    <AuthContext.Provider value={{
      user,
      isAuthenticated: !!user,
      progress,
      login,
      register,
      logout,
      updateProgress
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
