import { createContext, useContext, useState, useCallback, type ReactNode } from 'react';
import { questoes, type Questao } from '@/data/questoes';

interface QuizState {
  currentQuestionIndex: number;
  answers: Record<number, string>;
  showFeedback: boolean;
  isFinished: boolean;
  timeSpent: number;
  filteredQuestions: Questao[];
  selectedTopic: string | null;
  selectedDifficulty: string | null;
}

interface QuizContextType extends QuizState {
  startQuiz: (topic?: string | null, difficulty?: string | null) => void;
  answerQuestion: (questionId: number, alternative: string) => void;
  nextQuestion: () => void;
  previousQuestion: () => void;
  finishQuiz: () => void;
  resetQuiz: () => void;
  getCurrentQuestion: () => Questao | null;
  getResults: () => { total: number; correct: number; percentage: number };
}

const QuizContext = createContext<QuizContextType | undefined>(undefined);

const initialState: QuizState = {
  currentQuestionIndex: 0,
  answers: {},
  showFeedback: false,
  isFinished: false,
  timeSpent: 0,
  filteredQuestions: questoes,
  selectedTopic: null,
  selectedDifficulty: null
};

export function QuizProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<QuizState>(initialState);

  const startQuiz = useCallback((topic?: string | null, difficulty?: string | null) => {
    let filtered = [...questoes];
    
    if (topic) {
      filtered = filtered.filter(q => q.topico.toLowerCase().includes(topic.toLowerCase()));
    }
    
    if (difficulty) {
      filtered = filtered.filter(q => q.dificuldade === difficulty);
    }
    
    // Shuffle questions
    filtered = filtered.sort(() => Math.random() - 0.5);
    
    setState({
      ...initialState,
      filteredQuestions: filtered,
      selectedTopic: topic || null,
      selectedDifficulty: difficulty || null
    });
  }, []);

  const answerQuestion = useCallback((questionId: number, alternative: string) => {
    setState(prev => ({
      ...prev,
      answers: { ...prev.answers, [questionId]: alternative },
      showFeedback: true
    }));
  }, []);

  const nextQuestion = useCallback(() => {
    setState(prev => ({
      ...prev,
      currentQuestionIndex: prev.currentQuestionIndex + 1,
      showFeedback: false
    }));
  }, []);

  const previousQuestion = useCallback(() => {
    setState(prev => ({
      ...prev,
      currentQuestionIndex: Math.max(0, prev.currentQuestionIndex - 1),
      showFeedback: false
    }));
  }, []);

  const finishQuiz = useCallback(() => {
    setState(prev => ({ ...prev, isFinished: true }));
  }, []);

  const resetQuiz = useCallback(() => {
    setState(initialState);
  }, []);

  const getCurrentQuestion = useCallback(() => {
    return state.filteredQuestions[state.currentQuestionIndex] || null;
  }, [state.filteredQuestions, state.currentQuestionIndex]);

  const getResults = useCallback(() => {
    let correct = 0;
    
    state.filteredQuestions.forEach(q => {
      const answer = state.answers[q.id];
      if (answer) {
        const correctAlt = q.alternativas.find(a => a.correta);
        if (correctAlt && correctAlt.letra === answer) {
          correct++;
        }
      }
    });
    
    return {
      total: state.filteredQuestions.length,
      correct,
      percentage: state.filteredQuestions.length > 0 ? Math.round((correct / state.filteredQuestions.length) * 100) : 0
    };
  }, [state.filteredQuestions, state.answers]);

  return (
    <QuizContext.Provider value={{
      ...state,
      startQuiz,
      answerQuestion,
      nextQuestion,
      previousQuestion,
      finishQuiz,
      resetQuiz,
      getCurrentQuestion,
      getResults
    }}>
      {children}
    </QuizContext.Provider>
  );
}

export function useQuiz() {
  const context = useContext(QuizContext);
  if (context === undefined) {
    throw new Error('useQuiz must be used within a QuizProvider');
  }
  return context;
}
