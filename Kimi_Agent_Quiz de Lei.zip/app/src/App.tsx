import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { LandingPage } from '@/pages/LandingPage';
import { CadastroPage } from '@/pages/CadastroPage';
import { LoginPage } from '@/pages/LoginPage';
import { DashboardPage } from '@/pages/DashboardPage';
import { QuestoesPage } from '@/pages/QuestoesPage';
import { AuthProvider } from '@/hooks/useAuth';
import { QuizProvider } from '@/hooks/useQuiz';
import { Toaster } from '@/components/ui/sonner';

function App() {
  return (
    <AuthProvider>
      <QuizProvider>
        <Router>
          <div className="min-h-screen bg-[#0f172a]">
            <Routes>
              <Route path="/" element={
                <>
                  <Navbar />
                  <LandingPage />
                  <Footer />
                </>
              } />
              <Route path="/cadastro" element={<CadastroPage />} />
              <Route path="/login" element={<LoginPage />} />
              <Route path="/dashboard" element={
                <>
                  <Navbar />
                  <DashboardPage />
                  <Footer />
                </>
              } />
              <Route path="/questoes" element={
                <>
                  <Navbar />
                  <QuestoesPage />
                  <Footer />
                </>
              } />
            </Routes>
            <Toaster />
          </div>
        </Router>
      </QuizProvider>
    </AuthProvider>
  );
}

export default App;
