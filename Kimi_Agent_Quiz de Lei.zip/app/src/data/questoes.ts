export interface Alternativa {
  letra: string;
  texto: string;
  correta: boolean;
  justificativa: string;
}

export interface Questao {
  id: number;
  tipo: 'caso_concreto' | 'direta';
  dificuldade: 'facil' | 'media' | 'dificil';
  topico: string;
  artigos: string[];
  enunciado: string;
  alternativas: Alternativa[];
}

export const questoes: Questao[] = [
  // QUESTÕES SOBRE IMPEDIMENTO E SUSPEIÇÃO (arts. 144-155 CPC)
  {
    id: 1,
    tipo: 'caso_concreto',
    dificuldade: 'media',
    topico: 'Impedimento do Juiz',
    artigos: ['144', '145', '146', '147', '148', '149', '150', '151', '152', '153', '154', '155'],
    enunciado: `João ajuizou ação de indenização contra a Empresa X Ltda. O processo foi distribuído ao Juiz Dr. Carlos. Durante a tramitação, ficou comprovado que o Dr. Carlos é sócio de uma empresa que mantém contrato de prestação de serviços com a Empresa X Ltda., contrato este que representa 60% do faturamento mensal da empresa do juiz. Diante dessa situação, o advogado de João protocolou pedido de suspeição do juiz.`,
    alternativas: [
      {
        letra: 'A',
        texto: 'O pedido de suspeição procede, pois o juiz é considerado suspeito quando tiver interesse na causa, conforme art. 145, inciso I, do CPC.',
        correta: false,
        justificativa: 'INCORRETA. O art. 145, inciso I, refere-se à suspeição por interesse na causa. No caso apresentado, o juiz não tem interesse direto na causa, mas sim uma relação com uma das partes que caracteriza impedimento, não suspeição.'
      },
      {
        letra: 'B',
        texto: 'O pedido de suspeição não procede, pois a relação comercial entre a empresa do juiz e a parte ré não caracteriza hipótese legal de suspeição.',
        correta: false,
        justificativa: 'INCORRETA. A relação comercial descrita caracteriza impedimento, não apenas suspeição. O art. 144, inciso II, do CPC estabelece que é impedido o juiz que tiver relação de amizade ou inimizade íntima com alguma das partes ou seus procuradores, ou com sócio de pessoa jurídica parte no processo.'
      },
      {
        letra: 'C',
        texto: 'O pedido de suspeição não é o recurso adequado, pois o juiz está impedido de julgar a causa, devendo ser declarado o impedimento de ofício ou a requerimento das partes, nos termos do art. 144, inciso II, do CPC.',
        correta: true,
        justificativa: 'CORRETA. O art. 144, inciso II, do CPC estabelece como hipótese de impedimento a relação de amizade ou inimizade íntima com sócio de pessoa jurídica parte no processo. A relação comercial que representa 60% do faturamento da empresa do juiz configura amizade íntima no sentido jurídico. O procedimento correto é a declaração de impedimento, não de suspeição.'
      },
      {
        letra: 'D',
        texto: 'O pedido procede parcialmente, pois o juiz poderá continuar no processo desde que não haja prejuízo para as partes, conforme princípio da instrumentalidade dos formalismos.',
        correta: false,
        justificativa: 'INCORRETA. O impedimento é absoluto e não admite flexibilização. O juiz impedido não pode exercer a jurisdição no processo sob nenhuma hipótese, sendo obrigatória a sua substituição (art. 146 do CPC).'
      },
      {
        letra: 'E',
        texto: 'O pedido de suspeição procede, mas apenas se comprovado que o contrato entre as empresas foi celebrado após o ajuizamento da ação, configurando ato de improbidade.',
        correta: false,
        justificativa: 'INCORRETA. A data de celebração do contrato é irrelevante para a caracterização do impedimento. O que importa é a existência da relação no momento do julgamento. Além disso, o caso configura impedimento, não suspeição.'
      }
    ]
  },
  {
    id: 2,
    tipo: 'direta',
    dificuldade: 'facil',
    topico: 'Hipóteses de Impedimento',
    artigos: ['144', '145'],
    enunciado: `Assinale a alternativa correta acerca das hipóteses de impedimento e suspeição do juiz no processo civil:`,
    alternativas: [
      {
        letra: 'A',
        texto: 'O juiz é impedido de julgar a causa quando tiver interesse direto ou indireto no objeto da lide, conforme art. 145, inciso I, do CPC.',
        correta: false,
        justificativa: 'INCORRETA. O interesse direto ou indireto na causa configura suspeição (art. 145, inciso I), não impedimento. O impedimento está previsto no art. 144 do CPC.'
      },
      {
        letra: 'B',
        texto: 'O juiz é suspeito quando for cônjuge, companheiro, parente consanguíneo ou afim em linha reta ou colateral até o terceiro grau de qualquer das partes, conforme art. 144, inciso I, do CPC.',
        correta: false,
        justificativa: 'INCORRETA. Essa hipótese configura impedimento (art. 144, inciso I), não suspeição. A confusão entre impedimento e suspeição é comum, mas o CPC distingue claramente as duas figuras.'
      },
      {
        letra: 'C',
        texto: 'O juiz é impedido de julgar a causa quando for cônjuge, companheiro, parente consanguíneo ou afim em linha reta ou colateral até o terceiro grau de qualquer das partes, conforme art. 144, inciso I, do CPC.',
        correta: true,
        justificativa: 'CORRETA. O art. 144, inciso I, do CPC estabelece expressamente como hipótese de impedimento a condição de cônjuge, companheiro, parente consanguíneo ou afim em linha reta ou colateral até o terceiro grau de qualquer das partes.'
      },
      {
        letra: 'D',
        texto: 'O juiz é suspeito quando tiver aconselhado qualquer das partes sobre as questões de fato ou de direito relacionadas à causa, conforme art. 144, inciso III, do CPC.',
        correta: false,
        justificativa: 'INCORRETA. O aconselhamento sobre questões de fato ou de direito relacionadas à causa configura impedimento (art. 144, inciso III), não suspeição.'
      },
      {
        letra: 'E',
        texto: 'O impedimento e a suspeição são figuras jurídicas idênticas, podendo ser utilizadas indistintamente pelo juiz ou pelas partes.',
        correta: false,
        justificativa: 'INCORRETA. Impedimento e suspeição são figuras distintas. O impedimento é absoluto e deve ser declarado de ofício ou a requerimento (art. 146). A suspeição é relativa e depende de prova de prejuízo para a parte (art. 147).'
      }
    ]
  },
  {
    id: 3,
    tipo: 'caso_concreto',
    dificuldade: 'dificil',
    topico: 'Suspeição do Juiz',
    artigos: ['145', '146', '147', '148', '149', '150', '151', '152', '153', '154', '155'],
    enunciado: `Maria ajuizou ação de alimentos contra seu ex-marido Pedro. O processo foi distribuído ao Juiz Dr. Silva. Durante a tramitação, Maria descobriu que o Dr. Silva foi advogado de Pedro em ação de divórcio há mais de 15 anos, não havendo mais nenhum contato profissional entre eles desde então. Maria protocolou pedido de suspeição do juiz.`,
    alternativas: [
      {
        letra: 'A',
        texto: 'O pedido de suspeição procede, pois o juiz que foi advogado de parte é suspeito para julgar a causa, independentemente do tempo decorrido.',
        correta: false,
        justificativa: 'INCORRETA. O art. 145, inciso II, do CPC estabelece que é suspeito o juiz que tiver aconselhado qualquer das partes, não o que foi seu advogado. Além disso, o tempo decorrido de 15 anos sem contato profissional é relevante.'
      },
      {
        letra: 'B',
        texto: 'O pedido de suspeição não procede, pois o juiz é impedido, não suspeito, quando foi advogado de parte, e o impedimento deve ser declarado nos termos do art. 146 do CPC.',
        correta: false,
        justificativa: 'INCORRETA. Não há hipótese de impedimento ou suspeição específica para juiz que foi advogado de parte. O art. 145, inciso II, refere-se a quem aconselhou a parte, não a quem foi seu advogado formalmente.'
      },
      {
        letra: 'C',
        texto: 'O pedido de suspeição não procede, pois não há hipótese legal de suspeição ou impedimento configurada, uma vez que o exercício da advocacia por parte do juiz ocorreu há mais de 15 anos, não havendo mais relação profissional entre eles.',
        correta: true,
        justificativa: 'CORRETA. O CPC não prevê como hipótese de impedimento ou suspeição o fato de o juiz ter sido advogado de parte anteriormente. O art. 145, inciso II, refere-se a quem aconselhou a parte sobre questões da causa, não a relação profissional anterior de advocacia. Além disso, o tempo decorrido de 15 anos sem contato afasta qualquer suspeita de parcialidade.'
      },
      {
        letra: 'D',
        texto: 'O pedido de suspeição procede, pois o juiz é suspeito quando tiver relação de amizade íntima com alguma das partes, e o exercício da advocacia configura amizade íntima.',
        correta: false,
        justificativa: 'INCORRETA. O exercício da advocacia não configura, por si só, amizade íntima no sentido jurídico do art. 144, inciso II, do CPC. A relação de amizade íntima exige vínculo afetivo ou social próximo, não necessariamente profissional.'
      },
      {
        letra: 'E',
        texto: 'O pedido de suspeição procede parcialmente, pois o juiz poderá continuar no processo desde que não haja manifestação de prejuízo por parte de Pedro.',
        correta: false,
        justificativa: 'INCORRETA. Não há hipótese legal configurada para suspeição ou impedimento. O fato de não haver prejuízo manifestado não autoriza a manutenção do juiz quando não há suspeição ou impedimento.'
      }
    ]
  },

  // QUESTÕES SOBRE AUXILIARES DA JUSTIÇA (arts. 144-155 CPC)
  {
    id: 4,
    tipo: 'direta',
    dificuldade: 'facil',
    topico: 'Auxiliares da Justiça',
    artigos: ['144', '145', '146', '147', '148', '149', '150', '151', '152', '153', '154', '155'],
    enunciado: `Assinale a alternativa correta acerca dos auxiliares da justiça no processo civil:`,
    alternativas: [
      {
        letra: 'A',
        texto: 'Os auxiliares da justiça são o chefe de secretaria e o oficial de justiça, que atuam sob a supervisão direta do juiz.',
        correta: true,
        justificativa: 'CORRETA. O art. 144 e seguintes do CPC, combinado com a estrutura organizacional dos cartórios judiciais, estabelece que os auxiliares da justiça são o chefe de secretaria (ou escrivão) e o oficial de justiça, que atuam sob supervisão do juiz.'
      },
      {
        letra: 'B',
        texto: 'Os auxiliares da justiça são apenas os oficiais de justiça, pois o chefe de secretaria é considerado servidor administrativo, não auxiliar da justiça.',
        correta: false,
        justificativa: 'INCORRETA. O chefe de secretaria (escrivão) é considerado auxiliar da justiça, conforme a estrutura organizacional do Poder Judiciário e a doutrina processual civil.'
      },
      {
        letra: 'C',
        texto: 'Os auxiliares da justiça são nomeados diretamente pelo juiz, sem necessidade de concurso público.',
        correta: false,
        justificativa: 'INCORRETA. Os auxiliares da justiça (chefes de secretaria e oficiais de justiça) são servidores públicos que devem ser nomeados mediante concurso público, conforme a Constituição Federal e a legislação específica de cada tribunal.'
      },
      {
        letra: 'D',
        texto: 'Os auxiliares da justiça têm independência funcional para praticar todos os atos processuais, sem necessidade de supervisão do juiz.',
        correta: false,
        justificativa: 'INCORRETA. Os auxiliares da justiça atuam sob supervisão do juiz e não possuem independência funcional. Seus atos estão sujeitos à fiscalização e correção pelo juiz.'
      },
      {
        letra: 'E',
        texto: 'Os auxiliares da justiça são responsáveis apenas pela execução de mandados, não podendo praticar outros atos processuais.',
        correta: false,
        justificativa: 'INCORRETA. Os auxiliares da justiça têm atribuições variadas. O chefe de secretaria atua na organização dos processos e prática de atos processuais, enquanto o oficial de justiça atua na citação, intimação e execução de mandados.'
      }
    ]
  },

  // QUESTÕES SOBRE ATOS PROCESSUAIS E PRAZOS (arts. 188-275 CPC)
  {
    id: 5,
    tipo: 'caso_concreto',
    dificuldade: 'media',
    topico: 'Prazos Processuais',
    artigos: ['188', '189', '190', '191', '192', '193', '194', '195', '196', '197', '198', '199', '200', '201', '202', '203', '204', '205', '206', '207', '208', '209', '210', '211', '212', '213', '214', '215', '216', '217', '218', '219', '220', '221', '222', '223', '224', '225', '226', '227', '228', '229', '230', '231', '232', '233', '234', '235', '236', '237', '238', '239', '240', '241', '242', '243', '244', '245', '246', '247', '248', '249', '250', '251', '252', '253', '254', '255', '256', '257', '258', '259', '260', '261', '262', '263', '264', '265', '266', '267', '268', '269', '270', '271', '272', '273', '274', '275'],
    enunciado: `A Empresa ABC Ltda. foi citada em ação de cobrança no dia 10 de março de 2024 (domingo). O prazo para apresentação de contestação é de 15 dias. Considerando que não houve feriados no período, assinale a alternativa correta sobre o término do prazo:`,
    alternativas: [
      {
        letra: 'A',
        texto: 'O prazo termina no dia 25 de março de 2024, pois o prazo de 15 dias conta-se a partir do dia seguinte à citação.',
        correta: false,
        justificativa: 'INCORRETA. O art. 219 do CPC estabelece que o prazo só começa a correr no primeiro dia útil seguinte ao evento que lhe deu origem. Como a citação ocorreu em domingo, o prazo começa a correr no dia 11 de março (segunda-feira).'
      },
      {
        letra: 'B',
        texto: 'O prazo termina no dia 26 de março de 2024, pois o prazo começa a correr no primeiro dia útil seguinte à citação, excluindo-se o dia do começo e incluindo-se o dia do vencimento.',
        correta: false,
        justificativa: 'INCORRETA. Embora o prazo comece a correr no dia 11 de março (primeiro dia útil após a citação em domingo), o cálculo de 15 dias contados do dia 11 resulta no dia 25 de março, não 26.'
      },
      {
        letra: 'C',
        texto: 'O prazo termina no dia 25 de março de 2024, pois o prazo começa a correr no primeiro dia útil seguinte à citação (11 de março), e 15 dias contados a partir dessa data resultam no dia 25 de março.',
        correta: true,
        justificativa: 'CORRETA. O art. 219 do CPC estabelece que o prazo só começa a correr no primeiro dia útil seguinte ao evento que lhe deu origem. Como a citação foi em domingo (10/03), o prazo começa em 11/03. Contando 15 dias a partir de 11/03, o prazo termina em 25/03/2024.'
      },
      {
        letra: 'D',
        texto: 'O prazo termina no dia 24 de março de 2024, pois o dia da citação não conta para o prazo, devendo ser descontado do total de 15 dias.',
        correta: false,
        justificativa: 'INCORRETA. O art. 218 do CPC estabelece que exclui-se do cálculo o dia do começo e inclui-se o do vencimento. No caso, o dia da citação (domingo) já não conta porque o prazo só começa no primeiro dia útil seguinte (art. 219).'
      },
      {
        letra: 'E',
        texto: 'O prazo termina no dia 27 de março de 2024, pois o prazo é duplicado para pessoa jurídica, totalizando 30 dias.',
        correta: false,
        justificativa: 'INCORRETA. Não há previsão legal de prazo duplicado para pessoa jurídica na contestação. O prazo de 15 dias é igual para pessoas físicas e jurídicas, salvo disposição legal em contrário.'
      }
    ]
  },
  {
    id: 6,
    tipo: 'direta',
    dificuldade: 'facil',
    topico: 'Atos Processuais',
    artigos: ['188', '189', '190', '191', '192', '193', '194', '195', '196', '197', '198', '199', '200', '201', '202', '203', '204', '205', '206', '207', '208', '209', '210', '211', '212', '213', '214', '215', '216', '217', '218', '219', '220', '221', '222', '223', '224', '225', '226', '227', '228', '229', '230', '231', '232', '233', '234', '235', '236', '237', '238', '239', '240', '241', '242', '243', '244', '245', '246', '247', '248', '249', '250', '251', '252', '253', '254', '255', '256', '257', '258', '259', '260', '261', '262', '263', '264', '265', '266', '267', '268', '269', '270', '271', '272', '273', '274', '275'],
    enunciado: `Assinale a alternativa correta acerca dos atos processuais no processo civil:`,
    alternativas: [
      {
        letra: 'A',
        texto: 'Os atos processuais podem ser praticados em qualquer dia e horário, não havendo restrições legais.',
        correta: false,
        justificativa: 'INCORRETA. O art. 220 do CPC estabelece que os atos processuais somente podem ser praticados em dias úteis, das 6h às 20h, salvo disposição legal em contrário.'
      },
      {
        letra: 'B',
        texto: 'Os atos processuais somente podem ser praticados em dias úteis, das 6h às 20h, salvo disposição legal em contrário, conforme art. 220 do CPC.',
        correta: true,
        justificativa: 'CORRETA. O art. 220 do CPC estabelece expressamente que os atos processuais somente podem ser praticados em dias úteis, das 6h às 20h, salvo disposição legal em contrário.'
      },
      {
        letra: 'C',
        texto: 'Os atos processuais podem ser praticados em dias úteis, das 8h às 18h, conforme horário comercial padrão.',
        correta: false,
        justificativa: 'INCORRETA. O horário estabelecido no art. 220 do CPC é das 6h às 20h, não das 8h às 18h.'
      },
      {
        letra: 'D',
        texto: 'Os atos processuais podem ser praticados em qualquer horário, desde que sejam dias úteis.',
        correta: false,
        justificativa: 'INCORRETA. O art. 220 do CPC estabelece restrição tanto de dias (úteis) quanto de horário (6h às 20h).'
      },
      {
        letra: 'E',
        texto: 'Os atos processuais podem ser praticados em finais de semana e feriados, desde que haja autorização expressa do juiz.',
        correta: false,
        justificativa: 'INCORRETA. O art. 220 do CPC estabelece que os atos processuais somente podem ser praticados em dias úteis. A autorização do juiz não supre essa exigência legal, salvo disposição legal específica em contrário.'
      }
    ]
  },
  {
    id: 7,
    tipo: 'caso_concreto',
    dificuldade: 'dificil',
    topico: 'Citação e Intimação',
    artigos: ['188', '189', '190', '191', '192', '193', '194', '195', '196', '197', '198', '199', '200', '201', '202', '203', '204', '205', '206', '207', '208', '209', '210', '211', '212', '213', '214', '215', '216', '217', '218', '219', '220', '221', '222', '223', '224', '225', '226', '227', '228', '229', '230', '231', '232', '233', '234', '235', '236', '237', '238', '239', '240', '241', '242', '243', '244', '245', '246', '247', '248', '249', '250', '251', '252', '253', '254', '255', '256', '257', '258', '259', '260', '261', '262', '263', '264', '265', '266', '267', '268', '269', '270', '271', '272', '273', '274', '275'],
    enunciado: `João ajuizou ação de indenização contra Pedro. O oficial de justiça tentou a citação pessoal de Pedro em seu endereço residencial no dia 15 de maio de 2024 (quarta-feira), às 14h, mas não o encontrou. O oficial de justiça deixou aviso para que Pedro comparecesse ao cartório em 48 horas. Pedro compareceu ao cartório no dia 20 de maio de 2024 (segunda-feira), às 10h.`,
    alternativas: [
      {
        letra: 'A',
        texto: 'A citação é válida, pois Pedro compareceu ao cartório no prazo de 48 horas previsto no aviso.',
        correta: false,
        justificativa: 'INCORRETA. Pedro não compareceu no prazo de 48 horas. O aviso foi deixado no dia 15/05 (quarta-feira) às 14h, e o prazo de 48 horas terminaria no dia 17/05 (sexta-feira) às 14h. Pedro compareceu apenas no dia 20/05 (segunda-feira), fora do prazo.'
      },
      {
        letra: 'B',
        texto: 'A citação é inválida, pois Pedro não compareceu ao cartório no prazo de 48 horas, devendo ser realizada nova tentativa de citação pessoal.',
        correta: false,
        justificativa: 'INCORRETA. Embora Pedro não tenha comparecido no prazo de 48 horas, o art. 246 do CPC prevê que, se o citando não comparecer no prazo fixado, será citado por edital. Não é necessária nova tentativa de citação pessoal.'
      },
      {
        letra: 'C',
        texto: 'A citação é válida, pois o comparecimento de Pedro ao cartório, ainda que fora do prazo, configura citação por comparecimento voluntário, produzindo todos os efeitos da citação pessoal.',
        correta: false,
        justificativa: 'INCORRETA. O comparecimento voluntário fora do prazo fixado no aviso não configura citação válida. O art. 246 do CPC estabelece que, se o citando não comparecer no prazo fixado, será citado por edital.'
      },
      {
        letra: 'D',
        texto: 'A citação é inválida, pois Pedro não compareceu no prazo de 48 horas, devendo ser realizada citação por edital, nos termos do art. 246 do CPC.',
        correta: true,
        justificativa: 'CORRETA. O art. 246 do CPC estabelece que, se o citando não comparecer no prazo fixado no aviso, será citado por edital. Como Pedro compareceu apenas no dia 20/05, fora do prazo de 48 horas (que terminava em 17/05 às 14h), a citação deve ser realizada por edital.'
      },
      {
        letra: 'E',
        texto: 'A citação é válida, pois o prazo de 48 horas deve ser contado em dias úteis, e Pedro compareceu no primeiro dia útil após o prazo.',
        correta: false,
        justificativa: 'INCORRETA. O prazo de 48 horas é contado em horas corridas, não em dias úteis. Além disso, mesmo que fosse contado em dias úteis, Pedro compareceu apenas na segunda-feira, quando o prazo já havia expirado na sexta-feira.'
      }
    ]
  },

  // QUESTÕES SOBRE PARTES E PROCURADORES (arts. 188-275 CPC)
  {
    id: 8,
    tipo: 'direta',
    dificuldade: 'facil',
    topico: 'Partes no Processo Civil',
    artigos: ['188', '189', '190', '191', '192', '193', '194', '195', '196', '197', '198', '199', '200', '201', '202', '203', '204', '205', '206', '207', '208', '209', '210', '211', '212', '213', '214', '215', '216', '217', '218', '219', '220', '221', '222', '223', '224', '225', '226', '227', '228', '229', '230', '231', '232', '233', '234', '235', '236', '237', '238', '239', '240', '241', '242', '243', '244', '245', '246', '247', '248', '249', '250', '251', '252', '253', '254', '255', '256', '257', '258', '259', '260', '261', '262', '263', '264', '265', '266', '267', '268', '269', '270', '271', '272', '273', '274', '275'],
    enunciado: `Assinale a alternativa correta acerca das partes no processo civil:`,
    alternativas: [
      {
        letra: 'A',
        texto: 'A parte autora é aquela que propõe a ação, e a parte ré é aquela contra quem a ação é proposta, conforme art. 188 do CPC.',
        correta: true,
        justificativa: 'CORRETA. O art. 188 do CPC estabelece que a parte autora é aquela que propõe a ação, e a parte ré é aquela contra quem a ação é proposta.'
      },
      {
        letra: 'B',
        texto: 'A parte autora é sempre o autor da ação, e não pode ser representada por procurador.',
        correta: false,
        justificativa: 'INCORRETA. A parte autora pode ser representada por procurador, conforme arts. 189 e seguintes do CPC. A representação processual é regra geral no processo civil.'
      },
      {
        letra: 'C',
        texto: 'A parte ré é apenas aquela que contesta a ação, não podendo ser quem aceita a procedência do pedido.',
        correta: false,
        justificativa: 'INCORRETA. A parte ré é aquela contra quem a ação é proposta, independentemente de contestar ou aceitar o pedido. A aceitação do pedido configura revelia ou confissão, mas não exclui a condição de parte ré.'
      },
      {
        letra: 'D',
        texto: 'As partes no processo civil são apenas pessoas físicas, não podendo ser pessoas jurídicas.',
        correta: false,
        justificativa: 'INCORRETA. As partes no processo civil podem ser tanto pessoas físicas quanto pessoas jurídicas, conforme art. 188 e seguintes do CPC.'
      },
      {
        letra: 'E',
        texto: 'A parte autora e a parte ré são figuras fixas no processo, não podendo haver alteração durante a tramitação.',
        correta: false,
        justificativa: 'INCORRETA. Pode haver alteração de partes no processo, como a substituição processual, a intervenção de terceiros (assistência, oposição), e a habilitação de sucessor, conforme previsto no CPC.'
      }
    ]
  },
  {
    id: 9,
    tipo: 'caso_concreto',
    dificuldade: 'media',
    topico: 'Procuração e Representação Processual',
    artigos: ['188', '189', '190', '191', '192', '193', '194', '195', '196', '197', '198', '199', '200', '201', '202', '203', '204', '205', '206', '207', '208', '209', '210', '211', '212', '213', '214', '215', '216', '217', '218', '219', '220', '221', '222', '223', '224', '225', '226', '227', '228', '229', '230', '231', '232', '233', '234', '235', '236', '237', '238', '239', '240', '241', '242', '243', '244', '245', '246', '247', '248', '249', '250', '251', '252', '253', '254', '255', '256', '257', '258', '259', '260', '261', '262', '263', '264', '265', '266', '267', '268', '269', '270', '271', '272', '273', '274', '275'],
    enunciado: `Maria ajuizou ação de cobrança contra João, constando na procuração que o advogado Dr. Silva teria poderes para "propor ação, acompanhar seu curso e receber intimações". Durante o processo, surgiu a necessidade de Maria desistir da ação. O Dr. Silva protocolou petição de desistência, mas João questionou a validade do ato, alegando que o advogado não teria poderes específicos para desistir da ação.`,
    alternativas: [
      {
        letra: 'A',
        texto: 'A desistência é válida, pois os poderes para propor ação e acompanhar seu curso incluem implicitamente o poder para desistir da ação.',
        correta: false,
        justificativa: 'INCORRETA. O art. 189 do CPC estabelece que o advogado deve ter poderes específicos para praticar certos atos, como desistir da ação, renunciar ao direito, transigir, firmar compromisso arbitral e dar quitação. Os poderes gerais não incluem esses atos.'
      },
      {
        letra: 'B',
        texto: 'A desistência é inválida, pois o advogado não tem poderes para desistir da ação sem procuração específica, conforme art. 189, §1º, do CPC.',
        correta: true,
        justificativa: 'CORRETA. O art. 189, §1º, do CPC estabelece que dependem de procuração especial os atos de desistência da ação, renúncia ao direito sobre o qual se funda o pedido, transação, compromisso arbitral, reconhecimento da procedência do pedido, oposição de embargos de terceiro e penhora, e ainda a prática dos atos previstos nos arts. 331, 516, 517 e 1.022. A desistência da ação requer poderes específicos.'
      },
      {
        letra: 'C',
        texto: 'A desistência é válida, pois o advogado tem poderes gerais para praticar todos os atos processuais em nome da parte.',
        correta: false,
        justificativa: 'INCORRETA. O advogado não tem poderes ilimitados. O art. 189, §1º, do CPC estabelece atos que dependem de procuração especial, independentemente de cláusulas genéricas de representação.'
      },
      {
        letra: 'D',
        texto: 'A desistência é válida, pois a parte pode ratificar o ato do advogado posteriormente, sanando qualquer vício de representação.',
        correta: false,
        justificativa: 'INCORRETA. Embora a ratifique seja possível em alguns casos, o art. 189, §1º, do CPC estabelece que os atos ali previstos dependem de procuração especial. A ausência de poderes específicos torna o ato inválido, não podendo ser sanado simplesmente por ratificação posterior.'
      },
      {
        letra: 'E',
        texto: 'A desistência é inválida, pois apenas a parte pessoalmente pode desistir da ação, não podendo ser representada por advogado nesse ato.',
        correta: false,
        justificativa: 'INCORRETA. A parte pode sim ser representada por advogado para desistir da ação, desde que o advogado tenha poderes específicos para tanto, conforme art. 189, §1º, do CPC.'
      }
    ]
  },

  // QUESTÕES SOBRE TUTELA PROVISÓRIA (arts. 294-311 CPC)
  {
    id: 10,
    tipo: 'direta',
    dificuldade: 'facil',
    topico: 'Tutela Provisória',
    artigos: ['294', '295', '296', '297', '298', '299', '300', '301', '302', '303', '304', '305', '306', '307', '308', '309', '310', '311'],
    enunciado: `Assinale a alternativa correta acerca da tutela provisória no processo civil:`,
    alternativas: [
      {
        letra: 'A',
        texto: 'A tutela provisória pode ser concedida em caráter antecedente ou incidental, conforme art. 294 do CPC.',
        correta: true,
        justificativa: 'CORRETA. O art. 294 do CPC estabelece que a tutela provisória pode ser concedida em caráter antecedente (antes do julgamento final) ou incidental (durante o processo).'
      },
      {
        letra: 'B',
        texto: 'A tutela provisória somente pode ser concedida em caráter antecedente, não sendo admitida a concessão incidental.',
        correta: false,
        justificativa: 'INCORRETA. O art. 294 do CPC estabelece expressamente que a tutela provisória pode ser concedida em caráter antecedente ou incidental.'
      },
      {
        letra: 'C',
        texto: 'A tutela provisória é concedida automaticamente em todos os processos, independentemente de requerimento da parte.',
        correta: false,
        justificativa: 'INCORRETA. A tutela provisória depende de requerimento da parte e análise dos requisitos legais pelo juiz, conforme arts. 295 e seguintes do CPC.'
      },
      {
        letra: 'D',
        texto: 'A tutela provisória somente pode ser concedida mediante caução prévia da parte autora.',
        correta: false,
        justificativa: 'INCORRETA. A caução é uma das medidas que o juiz pode determinar (art. 300 do CPC), mas não é requisito obrigatório para a concessão da tutela provisória.'
      },
      {
        letra: 'E',
        texto: 'A tutela provisória é irrevogável, não podendo ser modificada ou revogada pelo juiz após sua concessão.',
        correta: false,
        justificativa: 'INCORRETA. O art. 299 do CPC estabelece que o juiz pode, a qualquer tempo, reconsiderar de ofício ou a requerimento da parte a decisão que concedeu, modificou ou revogou a tutela provisória.'
      }
    ]
  },
  {
    id: 11,
    tipo: 'caso_concreto',
    dificuldade: 'media',
    topico: 'Tutela de Urgência',
    artigos: ['294', '295', '296', '297', '298', '299', '300', '301', '302', '303', '304', '305', '306', '307', '308', '309', '310', '311'],
    enunciado: `A Empresa X Ltda. ajuizou ação contra a Empresa Y Ltda. por descumprimento contratual, pleiteando tutela de urgência para impedir que a Empresa Y utilizasse informações comerciais confidenciais obtidas durante a relação contratual. A Empresa X demonstrou que a divulgação dessas informações causaria prejuízo irreparável ou de difícil reparação. O juiz analisou o pedido.`,
    alternativas: [
      {
        letra: 'A',
        texto: 'O pedido de tutela de urgência procede, pois a demonstração de prejuízo irreparável ou de difícil reparação é suficiente para a concessão da tutela.',
        correta: false,
        justificativa: 'INCORRETA. Além do prejuízo irreparável ou de difícil reparação, é necessária a demonstração da probabilidade do direito (fumus boni iuris), conforme art. 297 do CPC.'
      },
      {
        letra: 'B',
        texto: 'O pedido de tutela de urgência não procede, pois tutela de urgência somente pode ser concedida em casos de violência ou grave ameaça, conforme art. 298 do CPC.',
        correta: false,
        justificativa: 'INCORRETA. A tutela de evidência (art. 298) é concedida em casos de violência ou grave ameaça, dentre outras hipóteses. A tutela de urgência (art. 297) tem requisitos diferentes.'
      },
      {
        letra: 'C',
        texto: 'O pedido de tutela de urgência procede se houver demonstração conjunta da probabilidade do direito e do perigo de dano ou do risco ao resultado útil do processo, conforme art. 297 do CPC.',
        correta: true,
        justificativa: 'CORRETA. O art. 297 do CPC estabelece como requisitos para a tutela de urgência a demonstração da probabilidade do direito (fumus boni iuris) e do perigo de dano ou do risco ao resultado útil do processo (periculum in mora). Ambos os requisitos devem estar presentes.'
      },
      {
        letra: 'D',
        texto: 'O pedido de tutela de urgência não procede, pois tutela de urgência somente pode ser concedida em ações de natureza alimentar.',
        correta: false,
        justificativa: 'INCORRETA. A tutela de urgência pode ser concedida em qualquer tipo de ação, desde que preenchidos os requisitos do art. 297 do CPC, não se limitando a ações alimentares.'
      },
      {
        letra: 'E',
        texto: 'O pedido de tutela de urgência procede automaticamente, pois a mera alegação de prejuízo irreparável é suficiente para a concessão.',
        correta: false,
        justificativa: 'INCORRETA. A tutela de urgência não é concedida automaticamente. É necessária a demonstração de ambos os requisitos do art. 297 do CPC: probabilidade do direito e perigo de dano ou risco ao resultado útil do processo.'
      }
    ]
  },
  {
    id: 12,
    tipo: 'caso_concreto',
    dificuldade: 'dificil',
    topico: 'Tutela de Evidência',
    artigos: ['294', '295', '296', '297', '298', '299', '300', '301', '302', '303', '304', '305', '306', '307', '308', '309', '310', '311'],
    enunciado: `João ajuizou ação de indenização contra Pedro, alegando que Pedro lhe causou lesões corporais em agressão física. João apresentou boletim de ocorrência, laudo médico e testemunhas que confirmaram a agressão. João requereu tutela de evidência para que Pedro fosse obrigado a pagar pensão mensal enquanto durasse o tratamento médico.`,
    alternativas: [
      {
        letra: 'A',
        texto: 'O pedido de tutela de evidência procede, pois a violência física configurada caracteriza hipótese do art. 298, inciso I, do CPC.',
        correta: false,
        justificativa: 'INCORRETA. O art. 298, inciso I, refere-se a abuso de direito de defesa ou ao manifesto propósito de dificultar o andamento do processo. A violência física configura hipótese do inciso II (violência ou grave ameaça).'
      },
      {
        letra: 'B',
        texto: 'O pedido de tutela de evidência procede, pois a violência física sofrida por João caracteriza hipótese do art. 298, inciso II, do CPC.',
        correta: true,
        justificativa: 'CORRETA. O art. 298, inciso II, do CPC estabelece como hipótese de tutela de evidência a violência ou a grave ameaça. A agressão física sofrida por João configura violência, atendendo ao requisito legal.'
      },
      {
        letra: 'C',
        texto: 'O pedido de tutela de evidência não procede, pois a tutela de evidência somente pode ser concedida em casos de abuso de direito de defesa.',
        correta: false,
        justificativa: 'INCORRETA. O art. 298 do CPC estabelece várias hipóteses de tutela de evidência, não se limitando ao abuso de direito de defesa (inciso I). A violência ou grave ameaça (inciso II) é outra hipótese independente.'
      },
      {
        letra: 'D',
        texto: 'O pedido de tutela de evidência não procede, pois João deveria ter requerido tutela de urgência, não de evidência.',
        correta: false,
        justificativa: 'INCORRETA. Embora João pudesse requerer tutela de urgência, a violência física configura hipótese específica de tutela de evidência (art. 298, inciso II), que tem requisitos mais flexíveis.'
      },
      {
        letra: 'E',
        texto: 'O pedido de tutela de evidência procede automaticamente, pois a mera alegação de violência é suficiente para a concessão.',
        correta: false,
        justificativa: 'INCORRETA. A tutela de evidência requer demonstração da hipótese legal prevista no art. 298 do CPC. A mera alegação não é suficiente; é necessária a comprovação da violência ou da hipótese invocada.'
      }
    ]
  },

  // QUESTÕES SOBRE PROCEDIMENTO COMUM (arts. 318-538 CPC)
  {
    id: 13,
    tipo: 'direta',
    dificuldade: 'facil',
    topico: 'Procedimento Comum',
    artigos: ['318', '319', '320', '321', '322', '323', '324', '325', '326', '327', '328', '329', '330', '331', '332', '333', '334', '335', '336', '337', '338', '339', '340', '341', '342', '343', '344', '345', '346', '347', '348', '349', '350', '351', '352', '353', '354', '355', '356', '357', '358', '359', '360', '361', '362', '363', '364', '365', '366', '367', '368', '369', '370', '371', '372', '373', '374', '375', '376', '377', '378', '379', '380', '381', '382', '383', '384', '385', '386', '387', '388', '389', '390', '391', '392', '393', '394', '395', '396', '397', '398', '399', '400', '401', '402', '403', '404', '405', '406', '407', '408', '409', '410', '411', '412', '413', '414', '415', '416', '417', '418', '419', '420', '421', '422', '423', '424', '425', '426', '427', '428', '429', '430', '431', '432', '433', '434', '435', '436', '437', '438', '439', '440', '441', '442', '443', '444', '445', '446', '447', '448', '449', '450', '451', '452', '453', '454', '455', '456', '457', '458', '459', '460', '461', '462', '463', '464', '465', '466', '467', '468', '469', '470', '471', '472', '473', '474', '475', '476', '477', '478', '479', '480', '481', '482', '483', '484', '485', '486', '487', '488', '489', '490', '491', '492', '493', '494', '495', '496', '497', '498', '499', '500', '501', '502', '503', '504', '505', '506', '507', '508', '509', '510', '511', '512', '513', '514', '515', '516', '517', '518', '519', '520', '521', '522', '523', '524', '525', '526', '527', '528', '529', '530', '531', '532', '533', '534', '535', '536', '537', '538'],
    enunciado: `Assinale a alternativa correta acerca do procedimento comum no processo civil:`,
    alternativas: [
      {
        letra: 'A',
        texto: 'O procedimento comum é o regime processual ordinário aplicável às demandas que não tenham procedimento especial previsto em lei, conforme art. 318 do CPC.',
        correta: true,
        justificativa: 'CORRETA. O art. 318 do CPC estabelece que o procedimento comum rege as demandas que não tenham procedimento especial previsto em lei, sendo o regime processual ordinário.'
      },
      {
        letra: 'B',
        texto: 'O procedimento comum somente pode ser utilizado em ações de natureza cível, não se aplicando a ações de natureza comercial.',
        correta: false,
        justificativa: 'INCORRETA. O procedimento comum aplica-se a todas as demandas que não tenham procedimento especial, independentemente da natureza cível, comercial ou de outra espécie.'
      },
      {
        letra: 'C',
        texto: 'O procedimento comum é obrigatoriamente oral, não admitindo a forma escrita.',
        correta: false,
        justificativa: 'INCORRETA. O procedimento comum é predominantemente escrito, conforme arts. 319 e seguintes do CPC, que estabelecem requisitos da petição inicial escrita.'
      },
      {
        letra: 'D',
        texto: 'O procedimento comum é aplicável apenas em primeira instância, não se aplicando em segundo grau de jurisdição.',
        correta: false,
        justificativa: 'INCORRETA. O procedimento comum pode ser aplicável em diferentes graus de jurisdição, conforme a natureza da demanda e a previsão legal.'
      },
      {
        letra: 'E',
        texto: 'O procedimento comum é o mesmo que o procedimento sumário, previsto no CPC de 1973.',
        correta: false,
        justificativa: 'INCORRETA. O CPC de 2015 revogou o procedimento sumário e o procedimento sumaríssimo, unificando o procedimento comum. O procedimento comum atual é diferente do procedimento sumário do CPC/73.'
      }
    ]
  },
  {
    id: 14,
    tipo: 'caso_concreto',
    dificuldade: 'media',
    topico: 'Petição Inicial',
    artigos: ['318', '319', '320', '321', '322', '323', '324', '325', '326', '327', '328', '329', '330', '331', '332', '333', '334', '335', '336', '337', '338', '339', '340', '341', '342', '343', '344', '345', '346', '347', '348', '349', '350', '351', '352', '353', '354', '355', '356', '357', '358', '359', '360', '361', '362', '363', '364', '365', '366', '367', '368', '369', '370', '371', '372', '373', '374', '375', '376', '377', '378', '379', '380', '381', '382', '383', '384', '385', '386', '387', '388', '389', '390', '391', '392', '393', '394', '395', '396', '397', '398', '399', '400', '401', '402', '403', '404', '405', '406', '407', '408', '409', '410', '411', '412', '413', '414', '415', '416', '417', '418', '419', '420', '421', '422', '423', '424', '425', '426', '427', '428', '429', '430', '431', '432', '433', '434', '435', '436', '437', '438', '439', '440', '441', '442', '443', '444', '445', '446', '447', '448', '449', '450', '451', '452', '453', '454', '455', '456', '457', '458', '459', '460', '461', '462', '463', '464', '465', '466', '467', '468', '469', '470', '471', '472', '473', '474', '475', '476', '477', '478', '479', '480', '481', '482', '483', '484', '485', '486', '487', '488', '489', '490', '491', '492', '493', '494', '495', '496', '497', '498', '499', '500', '501', '502', '503', '504', '505', '506', '507', '508', '509', '510', '511', '512', '513', '514', '515', '516', '517', '518', '519', '520', '521', '522', '523', '524', '525', '526', '527', '528', '529', '530', '531', '532', '533', '534', '535', '536', '537', '538'],
    enunciado: `Maria ajuizou ação de cobrança contra João, mas não indicou na petição inicial o valor exato do débito, limitando-se a informar que o valor seria apurado em liquidação de sentença. O juiz, ao analisar a petição inicial, deve:`,
    alternativas: [
      {
        letra: 'A',
        texto: 'Receber a petição inicial, pois a indicação do valor exato não é obrigatória, podendo ser apurado em liquidação de sentença.',
        correta: false,
        justificativa: 'INCORRETA. O art. 319, inciso IV, do CPC exige que a petição inicial contenha o valor da causa, quando tiver avaliação econômica. A ausência dessa indicação pode impedir o recebimento da inicial.'
      },
      {
        letra: 'B',
        texto: 'Determinar a emenda da petição inicial para que Maria especifique o valor do débito, nos termos do art. 321 do CPC.',
        correta: false,
        justificativa: 'INCORRETA. O art. 321 do CPC refere-se à emenda para incluir ou especificar fatos, não para indicar o valor da causa. A falta de indicação do valor pode ensejar a rejeição da petição inicial (art. 330).'
      },
      {
        letra: 'C',
        texto: 'Rejeitar a petição inicial, pois a indicação do valor da causa é requisito essencial da petição inicial, conforme art. 319, inciso IV, do CPC.',
        correta: true,
        justificativa: 'CORRETA. O art. 319, inciso IV, do CPC estabelece como requisito da petição inicial o valor da causa, quando tiver avaliação econômica. A ausência desse requisito pode ensejar a rejeição da petição inicial, conforme art. 330, inciso I, do CPC.'
      },
      {
        letra: 'D',
        texto: 'Fixar o valor da causa de ofício, com base em estimativa razoável do valor do débito.',
        correta: false,
        justificativa: 'INCORRETA. O juiz não pode fixar o valor da causa de ofício quando a parte não o indicou. O art. 319, inciso IV, impõe à parte a obrigação de indicar o valor da causa.'
      },
      {
        letra: 'E',
        texto: 'Receber a petição inicial e determinar a citação do réu, deixando para a fase de liquidação a apuração do valor exato.',
        correta: false,
        justificativa: 'INCORRETA. A indicação do valor da causa é requisito essencial da petição inicial. O juiz não pode receber a petição inicial sem esse requisito, salvo nas hipóteses em que a lei expressamente dispensa a indicação do valor.'
      }
    ]
  },
  {
    id: 15,
    tipo: 'caso_concreto',
    dificuldade: 'dificil',
    topico: 'Contestação e Reconvenção',
    artigos: ['318', '319', '320', '321', '322', '323', '324', '325', '326', '327', '328', '329', '330', '331', '332', '333', '334', '335', '336', '337', '338', '339', '340', '341', '342', '343', '344', '345', '346', '347', '348', '349', '350', '351', '352', '353', '354', '355', '356', '357', '358', '359', '360', '361', '362', '363', '364', '365', '366', '367', '368', '369', '370', '371', '372', '373', '374', '375', '376', '377', '378', '379', '380', '381', '382', '383', '384', '385', '386', '387', '388', '389', '390', '391', '392', '393', '394', '395', '396', '397', '398', '399', '400', '401', '402', '403', '404', '405', '406', '407', '408', '409', '410', '411', '412', '413', '414', '415', '416', '417', '418', '419', '420', '421', '422', '423', '424', '425', '426', '427', '428', '429', '430', '431', '432', '433', '434', '435', '436', '437', '438', '439', '440', '441', '442', '443', '444', '445', '446', '447', '448', '449', '450', '451', '452', '453', '454', '455', '456', '457', '458', '459', '460', '461', '462', '463', '464', '465', '466', '467', '468', '469', '470', '471', '472', '473', '474', '475', '476', '477', '478', '479', '480', '481', '482', '483', '484', '485', '486', '487', '488', '489', '490', '491', '492', '493', '494', '495', '496', '497', '498', '499', '500', '501', '502', '503', '504', '505', '506', '507', '508', '509', '510', '511', '512', '513', '514', '515', '516', '517', '518', '519', '520', '521', '522', '523', '524', '525', '526', '527', '528', '529', '530', '531', '532', '533', '534', '535', '536', '537', '538'],
    enunciado: `João ajuizou ação de cobrança contra Maria, referente a um empréstimo de R$ 50.000,00. Maria foi citada e apresentou contestação, arguindo prescrição e, subsidiariamente, pagamento parcial do débito. Na mesma petição, Maria formulou pedido contra João, pleiteando a condenação deste em danos morais por ter incluído indevidamente seu nome nos cadastros de inadimplentes antes do ajuizamento da ação.`,
    alternativas: [
      {
        letra: 'A',
        texto: 'O pedido de Maria contra João configura reconvenção, pois foi formulado na contestação e possui natureza jurídica autônoma, devendo ser processada e julgada conjuntamente com a ação principal.',
        correta: true,
        justificativa: 'CORRETA. O art. 343 do CPC estabelece que o réu pode formular pedido contra o autor por meio de reconvenção. A reconvenção é pedido autônomo, mas é processada e julgada conjuntamente com a ação principal, desde que haja conexão.'
      },
      {
        letra: 'B',
        texto: 'O pedido de Maria contra João não configura reconvenção, pois a reconvenção somente pode ser formulada em ações de natureza possessória.',
        correta: false,
        justificativa: 'INCORRETA. A reconvenção pode ser formulada em qualquer tipo de ação, não se limitando a ações possessórias. O art. 343 do CPC não restringe a reconvenção a nenhum tipo específico de ação.'
      },
      {
        letra: 'C',
        texto: 'O pedido de Maria contra João configura ação declaratória incidental, não reconvenção, pois visa à declaração de inexistência de dívida.',
        correta: false,
        justificativa: 'INCORRETA. O pedido de Maria não é ação declaratória incidental, mas sim reconvenção. A ação declaratória incidental (art. 485 do CPC) tem natureza e requisitos diferentes da reconvenção.'
      },
      {
        letra: 'D',
        texto: 'O pedido de Maria contra João deve ser processado separadamente, em ação autônoma, pois a reconvenção não é admitida no processo civil.',
        correta: false,
        justificativa: 'INCORRETA. A reconvenção é expressamente prevista no art. 343 do CPC e deve ser processada conjuntamente com a ação principal, desde que haja conexão entre os pedidos.'
      },
      {
        letra: 'E',
        texto: 'O pedido de Maria contra João configura reconvenção, mas deve ser rejeitado liminarmente por falta de conexão com a ação principal.',
        correta: false,
        justificativa: 'INCORRETA. Há conexão entre o pedido de Maria e a ação principal, pois ambos decorrem da mesma relação jurídica (empréstimo e cobrança). O art. 343 do CPC exige conexão para a reconvenção, e essa conexão está presente no caso.'
      }
    ]
  },
  {
    id: 16,
    tipo: 'direta',
    dificuldade: 'media',
    topico: 'Provas no Processo Civil',
    artigos: ['318', '319', '320', '321', '322', '323', '324', '325', '326', '327', '328', '329', '330', '331', '332', '333', '334', '335', '336', '337', '338', '339', '340', '341', '342', '343', '344', '345', '346', '347', '348', '349', '350', '351', '352', '353', '354', '355', '356', '357', '358', '359', '360', '361', '362', '363', '364', '365', '366', '367', '368', '369', '370', '371', '372', '373', '374', '375', '376', '377', '378', '379', '380', '381', '382', '383', '384', '385', '386', '387', '388', '389', '390', '391', '392', '393', '394', '395', '396', '397', '398', '399', '400', '401', '402', '403', '404', '405', '406', '407', '408', '409', '410', '411', '412', '413', '414', '415', '416', '417', '418', '419', '420', '421', '422', '423', '424', '425', '426', '427', '428', '429', '430', '431', '432', '433', '434', '435', '436', '437', '438', '439', '440', '441', '442', '443', '444', '445', '446', '447', '448', '449', '450', '451', '452', '453', '454', '455', '456', '457', '458', '459', '460', '461', '462', '463', '464', '465', '466', '467', '468', '469', '470', '471', '472', '473', '474', '475', '476', '477', '478', '479', '480', '481', '482', '483', '484', '485', '486', '487', '488', '489', '490', '491', '492', '493', '494', '495', '496', '497', '498', '499', '500', '501', '502', '503', '504', '505', '506', '507', '508', '509', '510', '511', '512', '513', '514', '515', '516', '517', '518', '519', '520', '521', '522', '523', '524', '525', '526', '527', '528', '529', '530', '531', '532', '533', '534', '535', '536', '537', '538'],
    enunciado: `Assinale a alternativa correta acerca das provas no processo civil:`,
    alternativas: [
      {
        letra: 'A',
        texto: 'O ônus da prova incumbe ao autor em todos os casos, não podendo ser invertido em hipótese alguma.',
        correta: false,
        justificativa: 'INCORRETA. O art. 373 do CPC estabelece que o ônus da prova incumbe ao autor quanto ao fato constitutivo de seu direito e ao réu quanto ao fato impeditivo, modificativo ou extintivo do direito do autor. Além disso, o art. 373, §1º, permite a inversão do ônus da prova em casos específicos.'
      },
      {
        letra: 'B',
        texto: 'O ônus da prova incumbe ao autor quanto ao fato constitutivo de seu direito e ao réu quanto ao fato impeditivo, modificativo ou extintivo do direito do autor, conforme art. 373 do CPC.',
        correta: true,
        justificativa: 'CORRETA. O art. 373, caput, do CPC estabelece expressamente essa distribuição do ônus da prova entre as partes.'
      },
      {
        letra: 'C',
        texto: 'O ônus da prova incumbe exclusivamente ao réu, pois é ele quem deve provar a inexistência do direito alegado pelo autor.',
        correta: false,
        justificativa: 'INCORRETA. O art. 373 do CPC estabelece que o autor deve provar o fato constitutivo de seu direito. Não é ao réu que cabe provar a inexistência do direito do autor.'
      },
      {
        letra: 'D',
        texto: 'O ônus da prova é sempre do juiz, que deve colher de ofício todas as provas necessárias para a formação de seu convencimento.',
        correta: false,
        justificativa: 'INCORRETA. O art. 373 do CPC estabelece que o ônus da prova cabe às partes, não ao juiz. O juiz pode determinar provas de ofício em casos específicos (art. 385 do CPC), mas isso não caracteriza inversão do ônus da prova.'
      },
      {
        letra: 'E',
        texto: 'O ônus da prova pode ser livremente distribuído entre as partes pelo juiz, conforme seu critério discricionário.',
        correta: false,
        justificativa: 'INCORRETA. O art. 373 do CPC estabelece critérios objetivos para a distribuição do ônus da prova, não admitindo distribuição discricionária pelo juiz.'
      }
    ]
  },

  // QUESTÕES SOBRE RECURSOS - APELAÇÃO (arts. 994-1026 CPC)
  {
    id: 17,
    tipo: 'direta',
    dificuldade: 'facil',
    topico: 'Recurso de Apelação',
    artigos: ['994', '995', '996', '997', '998', '999', '1000', '1001', '1002', '1003', '1004', '1005', '1006', '1007', '1008', '1009', '1010', '1011', '1012', '1013', '1014', '1015', '1016', '1017', '1018', '1019', '1020', '1021', '1022', '1023', '1024', '1025', '1026'],
    enunciado: `Assinale a alternativa correta acerca do recurso de apelação no processo civil:`,
    alternativas: [
      {
        letra: 'A',
        texto: 'A apelação é recurso cabível contra todas as decisões judiciais, independentemente de sua natureza.',
        correta: false,
        justificativa: 'INCORRETA. A apelação é cabível contra sentença (art. 1.009 do CPC), não contra todas as decisões judiciais. Decisões interlocutórias têm recurso próprio (agravo).'
      },
      {
        letra: 'B',
        texto: 'A apelação é recurso cabível contra sentença, conforme art. 1.009 do CPC, e deve ser interposta no prazo de 15 dias.',
        correta: true,
        justificativa: 'CORRETA. O art. 1.009 do CPC estabelece que cabe apelação da sentença. O prazo para interposição é de 15 dias, conforme art. 1.003 do CPC.'
      },
      {
        letra: 'C',
        texto: 'A apelação é recurso cabível apenas contra sentenças de mérito, não sendo admitida contra sentenças que extinguem o processo sem resolução de mérito.',
        correta: false,
        justificativa: 'INCORRETA. A apelação é cabível contra qualquer sentença, inclusive as que extinguem o processo sem resolução de mérito, conforme art. 1.009 do CPC.'
      },
      {
        letra: 'D',
        texto: 'A apelação é recurso que deve ser interposta diretamente no tribunal, não podendo ser protocolada no juízo de primeiro grau.',
        correta: false,
        justificativa: 'INCORRETA. A apelação é interposta perante o juiz de primeiro grau (art. 1.010 do CPC), que a encaminhará ao tribunal após o preparo.'
      },
      {
        letra: 'E',
        texto: 'A apelação não tem efeito suspensivo, devendo o autor cumprir imediatamente a sentença apelada.',
        correta: false,
        justificativa: 'INCORRETA. O art. 1.012 do CPC estabelece que a apelação suspende a eficácia da sentença, salvo quando a lei determinar o efeito meramente devolutivo.'
      }
    ]
  },
  {
    id: 18,
    tipo: 'caso_concreto',
    dificuldade: 'media',
    topico: 'Efeito Suspensivo da Apelação',
    artigos: ['994', '995', '996', '997', '998', '999', '1000', '1001', '1002', '1003', '1004', '1005', '1006', '1007', '1008', '1009', '1010', '1011', '1012', '1013', '1014', '1015', '1016', '1017', '1018', '1019', '1020', '1021', '1022', '1023', '1024', '1025', '1026'],
    enunciado: `João ajuizou ação de indenização contra a Empresa X Ltda., pleiteando danos materiais e morais. O juiz de primeiro grau julgou procedente o pedido e condenou a Empresa X ao pagamento de R$ 100.000,00. A Empresa X interpos apelação, alegando nulidade processual e improcedência do pedido. Após o protocolo da apelação, João requereu o imediato cumprimento da sentença, alegando que a apelação não tem efeito suspensivo.`,
    alternativas: [
      {
        letra: 'A',
        texto: 'João pode requerer o imediato cumprimento da sentença, pois a apelação não tem efeito suspensivo em ações de indenização.',
        correta: false,
        justificativa: 'INCORRETA. O art. 1.012 do CPC estabelece que a apelação suspende a eficácia da sentença, salvo quando a lei determinar o efeito meramente devolutivo. Não há disposição legal que afaste o efeito suspensivo em ações de indenização.'
      },
      {
        letra: 'B',
        texto: 'João não pode requerer o imediato cumprimento da sentença, pois a apelação tem efeito suspensivo, conforme art. 1.012 do CPC.',
        correta: true,
        justificativa: 'CORRETA. O art. 1.012 do CPC estabelece que a apelação suspende a eficácia da sentença, salvo quando a lei determinar o efeito meramente devolutivo. Como não há disposição legal em contrário, a apelação tem efeito suspensivo.'
      },
      {
        letra: 'C',
        texto: 'João pode requerer o imediato cumprimento da sentença, desde que preste caução suficiente para garantir o ressarcimento dos danos caso a apelação seja provida.',
        correta: false,
        justificativa: 'INCORRETA. O efeito suspensivo da apelação opera de pleno direito, independentemente de caução. A caução pode ser exigida em casos específicos previstos em lei, mas não como regra geral.'
      },
      {
        letra: 'D',
        texto: 'João pode requerer o imediato cumprimento da sentença parcialmente, limitado aos danos materiais, pois a apelação não tem efeito suspensivo sobre essa parte.',
        correta: false,
        justificativa: 'INCORRETA. O efeito suspensivo da apelação abrange a sentença em sua totalidade, não sendo possível seu fracionamento por natureza do dano.'
      },
      {
        letra: 'E',
        texto: 'João pode requerer o imediato cumprimento da sentença, pois o efeito suspensivo da apelação só opera se o apelante prestar caução.',
        correta: false,
        justificativa: 'INCORRETA. O art. 1.012 do CPC estabelece que a apelação suspende a eficácia da sentença de pleno direito, não condicionado à prestação de caução.'
      }
    ]
  },
  {
    id: 19,
    tipo: 'caso_concreto',
    dificuldade: 'dificil',
    topico: 'Preparo da Apelação',
    artigos: ['994', '995', '996', '997', '998', '999', '1000', '1001', '1002', '1003', '1004', '1005', '1006', '1007', '1008', '1009', '1010', '1011', '1012', '1013', '1014', '1015', '1016', '1017', '1018', '1019', '1020', '1021', '1022', '1023', '1024', '1025', '1026'],
    enunciado: `Maria foi condenada em ação de cobrança ao pagamento de R$ 50.000,00. Foi intimada da sentença no dia 10 de junho de 2024 (segunda-feira). No dia 20 de junho de 2024 (quinta-feira), Maria protocolou apelação, mas não recolheu o preparo no prazo. O juiz, ao analisar a apelação, deve:`,
    alternativas: [
      {
        letra: 'A',
        texto: 'Receber a apelação, pois o preparo pode ser recolhido em qualquer fase do processo, inclusive após o envio dos autos ao tribunal.',
        correta: false,
        justificativa: 'INCORRETA. O art. 1.013 do CPC estabelece que o preparo deve ser recolhido no prazo de 15 dias da interposição do recurso. O não recolhimento no prazo enseja a deserção do recurso.'
      },
      {
        letra: 'B',
        texto: 'Desertar a apelação, pois o preparo não foi recolhido no prazo de 15 dias da interposição do recurso, conforme art. 1.013 do CPC.',
        correta: true,
        justificativa: 'CORRETA. O art. 1.013 do CPC estabelece que o preparo deve ser recolhido no prazo de 15 dias da interposição do recurso, sob pena de deserção. Como Maria não recolheu o preparo no prazo, a apelação deve ser desertada.'
      },
      {
        letra: 'C',
        texto: 'Conceder prazo adicional de 10 dias para o recolhimento do preparo, considerando a natureza alimentar da obrigação.',
        correta: false,
        justificativa: 'INCORRETA. Não há previsão legal de prazo adicional para recolhimento do preparo. O prazo de 15 dias é peremptório, salvo hipóteses de concessão de gratuidade da justiça.'
      },
      {
        letra: 'D',
        texto: 'Receber a apelação e encaminhar os autos ao tribunal, deixando para o relator decidir sobre a regularidade do preparo.',
        correta: false,
        justificativa: 'INCORRETA. O juiz de primeiro grau deve verificar o preparo antes de encaminhar os autos ao tribunal. A falta de preparo no prazo enseja a deserção da apelação pelo juiz de primeiro grau.'
      },
      {
        letra: 'E',
        texto: 'Suspender o processo por 30 dias para que Maria possa recolher o preparo, considerando a gravidade da condenação.',
        correta: false,
        justificativa: 'INCORRETA. Não há previsão legal de suspensão do processo para recolhimento do preparo. O prazo de 15 dias é peremptório, não podendo ser prorrogado pelo juiz.'
      }
    ]
  },

  // QUESTÕES SOBRE JUIZADOS ESPECIAIS CÍVEIS (Lei 9.099/95)
  {
    id: 20,
    tipo: 'direta',
    dificuldade: 'facil',
    topico: 'Juizados Especiais Cíveis',
    artigos: ['3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19'],
    enunciado: `Assinale a alternativa correta acerca dos Juizados Especiais Cíveis, conforme a Lei nº 9.099/1995:`,
    alternativas: [
      {
        letra: 'A',
        texto: 'Os Juizados Especiais Cíveis são competentes para causas de valor até 40 salários mínimos, conforme art. 3º da Lei nº 9.099/1995.',
        correta: false,
        justificativa: 'INCORRETA. O art. 3º da Lei nº 9.099/1995 estabelece a competência dos Juizados Especiais Cíveis para causas de valor até 40 salários mínimos, mas essa foi alterada para 40 salários mínimos pelo art. 1º da Lei nº 12.153/2009. Atualmente, o valor é de até 40 salários mínimos, mas é importante verificar a redação atualizada.'
      },
      {
        letra: 'B',
        texto: 'Os Juizados Especiais Cíveis são competentes para causas de valor até 40 salários mínimos, conforme art. 3º da Lei nº 9.099/1995, com a redação dada pela Lei nº 12.153/2009.',
        correta: true,
        justificativa: 'CORRETA. O art. 3º da Lei nº 9.099/1995, com a redação dada pelo art. 1º da Lei nº 12.153/2009, estabelece a competência dos Juizados Especiais Cíveis para causas cujo valor não exceda a 40 salários mínimos.'
      },
      {
        letra: 'C',
        texto: 'Os Juizados Especiais Cíveis são competentes para causas de qualquer valor, não havendo limitação legal.',
        correta: false,
        justificativa: 'INCORRETA. Os Juizados Especiais Cíveis têm competência limitada por valor, conforme art. 3º da Lei nº 9.099/1995. Não são competentes para causas de qualquer valor.'
      },
      {
        letra: 'D',
        texto: 'Os Juizados Especiais Cíveis são competentes apenas para causas de valor até 20 salários mínimos.',
        correta: false,
        justificativa: 'INCORRETA. O valor de competência dos Juizados Especiais Cíveis é de até 40 salários mínimos, conforme art. 3º da Lei nº 9.099/1995, com a redação dada pela Lei nº 12.153/2009.'
      },
      {
        letra: 'E',
        texto: 'Os Juizados Especiais Cíveis são competentes apenas para causas de natureza alimentar, não se aplicando a outras espécies de demandas.',
        correta: false,
        justificativa: 'INCORRETA. Os Juizados Especiais Cíveis são competentes para causas cíveis em geral, desde que dentro do valor de competência, não se limitando a causas de natureza alimentar.'
      }
    ]
  },
  {
    id: 21,
    tipo: 'caso_concreto',
    dificuldade: 'media',
    topico: 'Procedimento nos Juizados Especiais Cíveis',
    artigos: ['3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19'],
    enunciado: `João ajuizou ação no Juizado Especial Cível contra Maria, pleiteando indenização por danos materiais no valor de R$ 15.000,00. A audiência de conciliação foi designada, mas Maria não compareceu, apesar de devidamente intimada. Diante dessa situação, o juiz deve:`,
    alternativas: [
      {
        letra: 'A',
        texto: 'Designar nova audiência de conciliação, pois a ausência da ré não impede a realização de nova tentativa de conciliação.',
        correta: false,
        justificativa: 'INCORRETA. O art. 9º da Lei nº 9.099/1995 estabelece que, na ausência do réu à audiência de conciliação, o juiz verificará se a citação foi regular e, se afirmativo, considerará o réu revel e prosseguirá no julgamento do processo.'
      },
      {
        letra: 'B',
        texto: 'Considerar a ré revel e prosseguir no julgamento do processo, se verificada a regularidade da citação, conforme art. 9º da Lei nº 9.099/1995.',
        correta: true,
        justificativa: 'CORRETA. O art. 9º da Lei nº 9.099/1995 estabelece que, na ausência do réu à audiência de conciliação, o juiz verificará se a citação foi regular e, se afirmativo, considerará o réu revel e prosseguirá no julgamento do processo.'
      },
      {
        letra: 'C',
        texto: 'Julgar o processo extinto sem resolução de mérito, por falta de interesse processual do autor.',
        correta: false,
        justificativa: 'INCORRETA. A ausência do réu à audiência de conciliação não configura falta de interesse processual do autor. O processo deve prosseguir com a revelia do réu.'
      },
      {
        letra: 'D',
        texto: 'Suspender o processo por 30 dias para nova intimação da ré.',
        correta: false,
        justificativa: 'INCORRETA. O art. 9º da Lei nº 9.099/1995 não prevê suspensão do processo para nova intimação. Se a citação foi regular, o réu é considerado revel e o processo prossegue.'
      },
      {
        letra: 'E',
        texto: 'Julgar o processo prejudicado, por ausência de ambas as partes à audiência.',
        correta: false,
        justificativa: 'INCORRETA. O autor compareceu à audiência (foi ele quem ajuizou a ação). A ausência apenas da ré não caracteriza ausência de ambas as partes.'
      }
    ]
  },
  {
    id: 22,
    tipo: 'direta',
    dificuldade: 'media',
    topico: 'Execução nos Juizados Especiais Cíveis',
    artigos: ['3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19'],
    enunciado: `Assinale a alternativa correta acerca da execução nos Juizados Especiais Cíveis:`,
    alternativas: [
      {
        letra: 'A',
        texto: 'A execução nos Juizados Especiais Cíveis segue o procedimento comum de execução previsto nos arts. 513 e seguintes do CPC.',
        correta: false,
        justificativa: 'INCORRETA. O art. 4º da Lei nº 9.099/1995 estabelece que a execução nos Juizados Especiais Cíveis observará o disposto nos arts. 513 a 536 do CPC, mas com peculiaridades próprias do procedimento dos juizados.'
      },
      {
        letra: 'B',
        texto: 'A execução nos Juizados Especiais Cíveis observa o disposto nos arts. 513 a 536 do CPC, mas com peculiaridades próprias do procedimento dos juizados, conforme art. 4º da Lei nº 9.099/1995.',
        correta: true,
        justificativa: 'CORRETA. O art. 4º da Lei nº 9.099/1995 estabelece que a execução observará o disposto nos arts. 513 a 536 do CPC, mas com as peculiaridades próprias do procedimento dos juizados especiais.'
      },
      {
        letra: 'C',
        texto: 'A execução nos Juizados Especiais Cíveis não é admitida, pois as decisões dos juizados são de cumprimento imediato e voluntário.',
        correta: false,
        justificativa: 'INCORRETA. A execução é admitida nos Juizados Especiais Cíveis, conforme art. 4º da Lei nº 9.099/1995. O cumprimento voluntário é desejável, mas não exclui a possibilidade de execução forçada.'
      },
      {
        letra: 'D',
        texto: 'A execução nos Juizados Especiais Cíveis somente pode ser promovida pelo juizado que proferiu a sentença.',
        correta: false,
        justificativa: 'INCORRETA. Não há restrição legal quanto ao órgão executor. A execução pode ser promovida no próprio juizado ou em outro órgão jurisdicional competente.'
      },
      {
        letra: 'E',
        texto: 'A execução nos Juizados Especiais Cíveis é sempre imediata, não admitindo prazo para cumprimento voluntário.',
        correta: false,
        justificativa: 'INCORRETA. O art. 4º da Lei nº 9.099/1995 não exclui a possibilidade de cumprimento voluntário no prazo previsto no art. 523 do CPC.'
      }
    ]
  },

  // QUESTÕES SOBRE JUIZADOS ESPECIAIS DE FAZENDA PÚBLICA (Lei 12.153/2009)
  {
    id: 23,
    tipo: 'direta',
    dificuldade: 'facil',
    topico: 'Juizados Especiais de Fazenda Pública',
    artigos: ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31', '32', '33', '34', '35', '36', '37', '38', '39', '40'],
    enunciado: `Assinale a alternativa correta acerca dos Juizados Especiais de Fazenda Pública, conforme a Lei nº 12.153/2009:`,
    alternativas: [
      {
        letra: 'A',
        texto: 'Os Juizados Especiais de Fazenda Pública são competentes para causas de valor até 40 salários mínimos, conforme art. 2º da Lei nº 12.153/2009.',
        correta: false,
        justificativa: 'INCORRETA. O art. 2º da Lei nº 12.153/2009 estabelece a competência dos Juizados Especiais de Fazenda Pública para causas de valor até 40 salários mínimos, mas essa foi alterada. Atualmente, o valor é de até 40 salários mínimos, mas é importante verificar a redação atualizada.'
      },
      {
        letra: 'B',
        texto: 'Os Juizados Especiais de Fazenda Pública são competentes para causas de valor até 40 salários mínimos, conforme art. 2º da Lei nº 12.153/2009, com as alterações posteriores.',
        correta: true,
        justificativa: 'CORRETA. O art. 2º da Lei nº 12.153/2009 estabelece a competência dos Juizados Especiais de Fazenda Pública para causas cujo valor não exceda a 40 salários mínimos (com as alterações posteriores).'
      },
      {
        letra: 'C',
        texto: 'Os Juizados Especiais de Fazenda Pública são competentes para causas de qualquer valor contra a Fazenda Pública.',
        correta: false,
        justificativa: 'INCORRETA. Os Juizados Especiais de Fazenda Pública têm competência limitada por valor, conforme art. 2º da Lei nº 12.153/2009. Não são competentes para causas de qualquer valor.'
      },
      {
        letra: 'D',
        texto: 'Os Juizados Especiais de Fazenda Pública são competentes apenas para causas de natureza tributária.',
        correta: false,
        justificativa: 'INCORRETA. Os Juizados Especiais de Fazenda Pública são competentes para causas cíveis em geral contra a Fazenda Pública, desde que dentro do valor de competência, não se limitando a causas tributárias.'
      },
      {
        letra: 'E',
        texto: 'Os Juizados Especiais de Fazenda Pública não têm competência para julgar causas contra a Fazenda Pública, pois estas são da competência exclusiva da Justiça Federal.',
        correta: false,
        justificativa: 'INCORRETA. Os Juizados Especiais de Fazenda Pública são justamente criados para julgar causas contra a Fazenda Pública estadual e municipal, conforme art. 1º da Lei nº 12.153/2009.'
      }
    ]
  },
  {
    id: 24,
    tipo: 'caso_concreto',
    dificuldade: 'media',
    topico: 'Procedimento nos Juizados Especiais de Fazenda Pública',
    artigos: ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31', '32', '33', '34', '35', '36', '37', '38', '39', '40'],
    enunciado: `João ajuizou ação no Juizado Especial de Fazenda Pública contra o Município de São Paulo, pleiteando indenização por danos materiais no valor de R$ 25.000,00, decorrentes de acidente causado por defeito em via pública. O Município foi citado e apresentou contestação, arguindo prescrição e ausência de responsabilidade. Diante dessa situação, o juiz deve:`,
    alternativas: [
      {
        letra: 'A',
        texto: 'Julgar o processo extinto sem resolução de mérito, pois o Juizado Especial de Fazenda Pública não é competente para julgar ação de indenização contra o Município.',
        correta: false,
        justificativa: 'INCORRETA. O Juizado Especial de Fazenda Pública é competente para julgar ações de indenização contra o Município, desde que dentro do valor de competência (até 40 salários mínimos), conforme art. 2º da Lei nº 12.153/2009.'
      },
      {
        letra: 'B',
        texto: 'Prosseguir no julgamento do processo, analisando o mérito da causa, inclusive as alegações de prescrição e ausência de responsabilidade, conforme procedimento dos Juizados Especiais de Fazenda Pública.',
        correta: true,
        justificativa: 'CORRETA. O Juizado Especial de Fazenda Pública é competente para julgar ações de indenização contra o Município, desde que dentro do valor de competência. O procedimento segue as regras dos juizados especiais, com audiência de conciliação e julgamento.'
      },
      {
        letra: 'C',
        texto: 'Remeter os autos à Justiça Comum, pois a alegação de prescrição retira a competência do Juizado Especial de Fazenda Pública.',
        correta: false,
        justificativa: 'INCORRETA. A alegação de prescrição não retira a competência do Juizado Especial de Fazenda Pública. O juizado pode analisar todas as questões de mérito, inclusive prescrição.'
      },
      {
        letra: 'D',
        texto: 'Julgar o processo prejudicado, pois a Fazenda Pública não pode ser demandada em Juizados Especiais.',
        correta: false,
        justificativa: 'INCORRETA. Os Juizados Especiais de Fazenda Pública são justamente criados para demandas contra a Fazenda Pública estadual e municipal, conforme art. 1º da Lei nº 12.153/2009.'
      },
      {
        letra: 'E',
        texto: 'Suspender o processo por 60 dias para que as partes tentem acordo administrativo.',
        correta: false,
        justificativa: 'INCORRETA. Não há previsão legal de suspensão obrigatória para tentativa de acordo administrativo nos Juizados Especiais de Fazenda Pública. O procedimento prevê audiência de conciliação, mas não suspensão prévia obrigatória.'
      }
    ]
  },
  {
    id: 25,
    tipo: 'caso_concreto',
    dificuldade: 'dificil',
    topico: 'Competência dos Juizados Especiais de Fazenda Pública',
    artigos: ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31', '32', '33', '34', '35', '36', '37', '38', '39', '40'],
    enunciado: `Maria ajuizou ação no Juizado Especial de Fazenda Pública contra o Estado de São Paulo, pleiteando o pagamento de R$ 45.000,00 referente a danos morais e materiais decorrentes de acidente em rodovia estadual. O valor da causa foi fixado em R$ 45.000,00. O Estado de São Paulo alegou, preliminarmente, incompetência do juizado, pois o valor excede a competência. Considerando que o salário mínimo vigente é de R$ 1.412,00, assinale a alternativa correta:`,
    alternativas: [
      {
        letra: 'A',
        texto: 'O juizado é competente, pois o valor de R$ 45.000,00 não excede 40 salários mínimos (R$ 56.480,00).',
        correta: true,
        justificativa: 'CORRETA. O art. 2º da Lei nº 12.153/2009 estabelece a competência dos Juizados Especiais de Fazenda Pública para causas de valor até 40 salários mínimos. Com salário mínimo de R$ 1.412,00, 40 salários mínimos equivalem a R$ 56.480,00. O valor de R$ 45.000,00 está dentro da competência.'
      },
      {
        letra: 'B',
        texto: 'O juizado é incompetente, pois o valor de R$ 45.000,00 excede 30 salários mínimos.',
        correta: false,
        justificativa: 'INCORRETA. A competência dos Juizados Especiais de Fazenda Pública é de até 40 salários mínimos, não 30. O valor de R$ 45.000,00 não excede 40 salários mínimos (R$ 56.480,00).'
      },
      {
        letra: 'C',
        texto: 'O juizado é incompetente, pois a competência é de até 20 salários mínimos para ações de indenização.',
        correta: false,
        justificativa: 'INCORRETA. A competência dos Juizados Especiais de Fazenda Pública é de até 40 salários mínimos, não havendo distinção por natureza da ação.'
      },
      {
        letra: 'D',
        texto: 'O juizado é incompetente, pois ações de indenização por acidente em rodovia são da competência exclusiva da Justiça Federal.',
        correta: false,
        justificativa: 'INCORRETA. Ações de indenização contra o Estado de São Paulo por acidente em rodovia estadual são da competência da Justiça Estadual, não Federal. O Juizado Especial de Fazenda Pública estadual é competente.'
      },
      {
        letra: 'E',
        texto: 'O juizado é competente, mas deve remeter os autos à Justiça Comum por se tratar de ação complexa.',
        correta: false,
        justificativa: 'INCORRETA. O valor de R$ 45.000,00 está dentro da competência do Juizado Especial de Fazenda Pública. Não há previsão legal de remessa à Justiça Comum por complexidade da ação.'
      }
    ]
  }
];

export const topicos = [
  { id: 'impedimento', nome: 'Impedimento e Suspeição', artigos: 'Arts. 144-155 CPC', totalQuestoes: 3 },
  { id: 'auxiliares', nome: 'Auxiliares da Justiça', artigos: 'Arts. 144-155 CPC', totalQuestoes: 1 },
  { id: 'prazos', nome: 'Atos Processuais e Prazos', artigos: 'Arts. 188-275 CPC', totalQuestoes: 3 },
  { id: 'partes', nome: 'Partes e Procuradores', artigos: 'Arts. 188-275 CPC', totalQuestoes: 2 },
  { id: 'tutela', nome: 'Tutela Provisória', artigos: 'Arts. 294-311 CPC', totalQuestoes: 3 },
  { id: 'procedimento', nome: 'Procedimento Comum', artigos: 'Arts. 318-538 CPC', totalQuestoes: 4 },
  { id: 'recursos', nome: 'Recursos - Apelação', artigos: 'Arts. 994-1026 CPC', totalQuestoes: 3 },
  { id: 'jec', nome: 'Juizados Especiais Cíveis', artigos: 'Lei 9.099/1995', totalQuestoes: 3 },
  { id: 'jefp', nome: 'Juizados Especiais de Fazenda Pública', artigos: 'Lei 12.153/2009', totalQuestoes: 3 }
];
