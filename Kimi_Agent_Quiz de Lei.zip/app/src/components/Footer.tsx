import { Link } from 'react-router-dom';
import { BookOpen, Scale, Mail, MapPin, Phone } from 'lucide-react';

export function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-[#0f172a] border-t border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="space-y-4">
            <Link to="/" className="flex items-center space-x-2">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#c9a227] to-[#a88a1f] flex items-center justify-center">
                <BookOpen className="w-5 h-5 text-[#0f172a]" />
              </div>
              <span className="text-xl font-bold text-white">
                Gabarita<span className="text-[#c9a227]">Escrevente</span>
              </span>
            </Link>
            <p className="text-gray-400 text-sm">
              Plataforma de estudos completa para o concurso de Escrevente do TJSP. 
              Questões no estilo Vunesp com justificativas detalhadas.
            </p>
          </div>

          {/* Links Rápidos */}
          <div>
            <h3 className="text-white font-semibold mb-4">Links Rápidos</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-gray-400 hover:text-[#c9a227] transition-colors text-sm">
                  Início
                </Link>
              </li>
              <li>
                <Link to="/questoes" className="text-gray-400 hover:text-[#c9a227] transition-colors text-sm">
                  Questões
                </Link>
              </li>
              <li>
                <Link to="/dashboard" className="text-gray-400 hover:text-[#c9a227] transition-colors text-sm">
                  Dashboard
                </Link>
              </li>
              <li>
                <Link to="/cadastro" className="text-gray-400 hover:text-[#c9a227] transition-colors text-sm">
                  Cadastro
                </Link>
              </li>
            </ul>
          </div>

          {/* Conteúdo */}
          <div>
            <h3 className="text-white font-semibold mb-4">Conteúdo</h3>
            <ul className="space-y-2">
              <li className="text-gray-400 text-sm flex items-center">
                <Scale className="w-4 h-4 mr-2 text-[#c9a227]" />
                Processo Civil
              </li>
              <li className="text-gray-400 text-sm flex items-center">
                <Scale className="w-4 h-4 mr-2 text-[#c9a227]" />
                Juizados Especiais
              </li>
              <li className="text-gray-400 text-sm flex items-center">
                <Scale className="w-4 h-4 mr-2 text-[#c9a227]" />
                Recursos
              </li>
              <li className="text-gray-400 text-sm flex items-center">
                <Scale className="w-4 h-4 mr-2 text-[#c9a227]" />
                Tutela Provisória
              </li>
            </ul>
          </div>

          {/* Contato */}
          <div>
            <h3 className="text-white font-semibold mb-4">Contato</h3>
            <ul className="space-y-3">
              <li className="flex items-start space-x-3">
                <Mail className="w-5 h-5 text-[#c9a227] mt-0.5" />
                <span className="text-gray-400 text-sm">contato@gabaritaescrevente.com.br</span>
              </li>
              <li className="flex items-start space-x-3">
                <Phone className="w-5 h-5 text-[#c9a227] mt-0.5" />
                <span className="text-gray-400 text-sm">(11) 3000-0000</span>
              </li>
              <li className="flex items-start space-x-3">
                <MapPin className="w-5 h-5 text-[#c9a227] mt-0.5" />
                <span className="text-gray-400 text-sm">São Paulo, SP</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom */}
        <div className="mt-12 pt-8 border-t border-white/10">
          <div className="flex flex-col md:flex-row items-center justify-between space-y-4 md:space-y-0">
            <p className="text-gray-500 text-sm text-center md:text-left">
              {currentYear} GabaritaEscrevente. Todos os direitos reservados.
            </p>
            <div className="flex items-center space-x-6">
              <Link to="#" className="text-gray-500 hover:text-[#c9a227] text-sm transition-colors">
                Termos de Uso
              </Link>
              <Link to="#" className="text-gray-500 hover:text-[#c9a227] text-sm transition-colors">
                Política de Privacidade
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
